create function cosd(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcosd$$;

comment on function cosd(double precision) is 'cosine, degrees';

alter function cosd(double precision) owner to marina;

