create function int4("char") returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$chartoi4$$;

comment on function int4(double precision) is 'convert float8 to int4';

alter function int4(double precision) owner to marina;

