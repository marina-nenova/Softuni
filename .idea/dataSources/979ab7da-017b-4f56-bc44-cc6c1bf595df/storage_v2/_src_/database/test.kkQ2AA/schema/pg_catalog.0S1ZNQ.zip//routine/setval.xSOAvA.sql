create function setval(regclass, bigint) returns bigint
    strict
    cost 1
    language internal
as
$$setval_oid$$;

comment on function setval(regclass, bigint) is 'set sequence value';

alter function setval(regclass, bigint) owner to marina;

