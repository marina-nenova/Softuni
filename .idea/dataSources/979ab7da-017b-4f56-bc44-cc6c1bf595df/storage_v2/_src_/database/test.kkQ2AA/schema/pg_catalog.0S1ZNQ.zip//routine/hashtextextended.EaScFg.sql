create function hashtextextended(text, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashtextextended$$;

comment on function hashtextextended(text, bigint) is 'hash';

alter function hashtextextended(text, bigint) owner to marina;

