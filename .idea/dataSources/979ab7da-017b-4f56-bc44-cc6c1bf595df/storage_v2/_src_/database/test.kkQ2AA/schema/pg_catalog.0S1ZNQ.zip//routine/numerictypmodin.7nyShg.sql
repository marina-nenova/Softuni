create function numerictypmodin(cstring[]) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$numerictypmodin$$;

comment on function numerictypmodin(cstring[]) is 'I/O typmod';

alter function numerictypmodin(cstring[]) owner to marina;

