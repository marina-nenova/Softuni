create function int4_accum(internal, integer) returns internal
    immutable
    parallel safe
    cost 1
    language internal
as
$$int4_accum$$;

comment on function int4_accum(internal, integer) is 'aggregate transition function';

alter function int4_accum(internal, integer) owner to marina;

