create function pg_safe_snapshot_blocking_pids(integer) returns integer[]
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_safe_snapshot_blocking_pids$$;

comment on function pg_safe_snapshot_blocking_pids(integer) is 'get array of PIDs of sessions blocking specified backend PID from acquiring a safe snapshot';

alter function pg_safe_snapshot_blocking_pids(integer) owner to marina;

