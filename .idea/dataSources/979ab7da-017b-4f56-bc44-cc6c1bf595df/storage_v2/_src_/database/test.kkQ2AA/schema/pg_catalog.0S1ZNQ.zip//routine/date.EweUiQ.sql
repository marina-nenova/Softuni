create function date(timestamp without time zone) returns date
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_date$$;

comment on function date(timestamp) is 'convert timestamp to date';

alter function date(timestamp) owner to marina;

