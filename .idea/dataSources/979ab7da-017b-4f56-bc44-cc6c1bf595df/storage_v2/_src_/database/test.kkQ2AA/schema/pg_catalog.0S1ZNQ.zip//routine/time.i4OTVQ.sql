create function time(timestamp without time zone) returns time without time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_time$$;

comment on function time(time, integer) is 'adjust time precision';

alter function time(time, integer) owner to marina;

