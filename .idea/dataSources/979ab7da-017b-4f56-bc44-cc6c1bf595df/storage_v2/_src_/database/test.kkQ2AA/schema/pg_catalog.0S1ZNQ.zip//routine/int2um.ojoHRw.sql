create function int2um(smallint) returns smallint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int2um$$;

comment on function int2um(smallint) is 'implementation of - operator';

alter function int2um(smallint) owner to marina;

