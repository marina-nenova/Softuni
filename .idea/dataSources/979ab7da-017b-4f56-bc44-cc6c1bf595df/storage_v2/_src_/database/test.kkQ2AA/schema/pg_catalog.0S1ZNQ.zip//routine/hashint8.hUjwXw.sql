create function hashint8(bigint) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashint8$$;

comment on function hashint8(bigint) is 'hash';

alter function hashint8(bigint) owner to marina;

