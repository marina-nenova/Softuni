create function timestamp_lt_timestamptz(timestamp without time zone, timestamp with time zone) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_lt_timestamptz$$;

comment on function timestamp_lt_timestamptz(timestamp, timestamp with time zone) is 'implementation of < operator';

alter function timestamp_lt_timestamptz(timestamp, timestamp with time zone) owner to marina;

