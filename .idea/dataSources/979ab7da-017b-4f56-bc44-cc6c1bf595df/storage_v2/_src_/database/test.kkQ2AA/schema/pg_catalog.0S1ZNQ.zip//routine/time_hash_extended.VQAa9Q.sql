create function time_hash_extended(time without time zone, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$time_hash_extended$$;

comment on function time_hash_extended(time, bigint) is 'hash';

alter function time_hash_extended(time, bigint) owner to marina;

