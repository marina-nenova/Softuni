create function int8_avg_accum_inv(internal, bigint) returns internal
    immutable
    parallel safe
    cost 1
    language internal
as
$$int8_avg_accum_inv$$;

comment on function int8_avg_accum_inv(internal, bigint) is 'aggregate transition function';

alter function int8_avg_accum_inv(internal, bigint) owner to marina;

