create function pg_options_to_table(options_array text[], OUT option_name text, OUT option_value text) returns SETOF record
    stable
    strict
    parallel safe
    cost 1
    rows 3
    language internal
as
$$pg_options_to_table$$;

comment on function pg_options_to_table(text[], out text, out text) is 'convert generic options array to name/value table';

alter function pg_options_to_table(text[], out text, out text) owner to marina;

