create function lseg(box) returns lseg
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_diagonal$$;

comment on function lseg(box, point) is 'diagonal of';

alter function lseg(box, point) owner to marina;

