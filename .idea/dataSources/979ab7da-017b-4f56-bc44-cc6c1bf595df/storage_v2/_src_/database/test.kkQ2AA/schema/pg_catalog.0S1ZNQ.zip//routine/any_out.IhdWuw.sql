create function any_out("any") returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$any_out$$;

comment on function any_out("any") is 'I/O';

alter function any_out("any") owner to marina;

