create function cotd(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcotd$$;

comment on function cotd(double precision) is 'cotangent, degrees';

alter function cotd(double precision) owner to marina;

