create function datetimetz_pl(date, time with time zone) returns timestamp with time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$datetimetz_timestamptz$$;

comment on function datetimetz_pl(date, time with time zone) is 'implementation of + operator';

alter function datetimetz_pl(date, time with time zone) owner to marina;

