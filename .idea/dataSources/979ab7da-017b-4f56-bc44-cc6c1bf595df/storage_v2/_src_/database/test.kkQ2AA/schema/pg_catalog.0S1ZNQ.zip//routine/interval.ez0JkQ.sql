create function interval(time without time zone) returns interval
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$time_interval$$;

comment on function interval(interval, integer) is 'adjust interval precision';

alter function interval(interval, integer) owner to marina;

