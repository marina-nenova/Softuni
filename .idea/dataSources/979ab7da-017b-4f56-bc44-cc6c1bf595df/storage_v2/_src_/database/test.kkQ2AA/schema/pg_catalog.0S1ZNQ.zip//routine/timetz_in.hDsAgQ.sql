create function timetz_in(cstring, oid, integer) returns time with time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timetz_in$$;

comment on function timetz_in(cstring, oid, integer) is 'I/O';

alter function timetz_in(cstring, oid, integer) owner to marina;

