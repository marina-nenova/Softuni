create function timezone(interval, timestamp with time zone) returns timestamp without time zone
    language internal
as
$$timestamptz_izone$$;

comment on function timezone(text, timetz) is 'adjust time with time zone to new zone';

