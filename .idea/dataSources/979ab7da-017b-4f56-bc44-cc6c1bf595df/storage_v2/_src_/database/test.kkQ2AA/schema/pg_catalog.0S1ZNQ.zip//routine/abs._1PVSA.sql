create function abs(real) returns real
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float4abs$$;

comment on function abs(integer) is 'absolute value';

alter function abs(integer) owner to marina;

