create function xideqint4(xid, integer) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$xideq$$;

comment on function xideqint4(xid, integer) is 'implementation of = operator';

alter function xideqint4(xid, integer) owner to marina;

