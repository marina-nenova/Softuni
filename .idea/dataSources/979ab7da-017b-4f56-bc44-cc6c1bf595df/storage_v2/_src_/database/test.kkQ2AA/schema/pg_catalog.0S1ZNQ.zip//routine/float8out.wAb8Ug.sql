create function float8out(double precision) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8out$$;

comment on function float8out(double precision) is 'I/O';

alter function float8out(double precision) owner to marina;

