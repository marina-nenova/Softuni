create function hashbpchar(character) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashbpchar$$;

comment on function hashbpchar(char) is 'hash';

alter function hashbpchar(char) owner to marina;

