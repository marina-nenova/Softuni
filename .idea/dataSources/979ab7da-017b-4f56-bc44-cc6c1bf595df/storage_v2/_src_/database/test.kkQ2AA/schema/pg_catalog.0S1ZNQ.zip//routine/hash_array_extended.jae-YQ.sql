create function hash_array_extended(anyarray, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hash_array_extended$$;

comment on function hash_array_extended(anyarray, bigint) is 'hash';

alter function hash_array_extended(anyarray, bigint) owner to marina;

