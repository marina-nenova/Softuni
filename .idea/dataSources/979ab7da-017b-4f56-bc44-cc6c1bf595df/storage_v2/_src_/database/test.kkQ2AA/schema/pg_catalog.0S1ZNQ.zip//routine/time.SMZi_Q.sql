create function time(timestamp without time zone) returns time without time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_time$$;

comment on function time(interval, int4) is 'convert interval to time';

alter function time(interval, int4) owner to marina;

