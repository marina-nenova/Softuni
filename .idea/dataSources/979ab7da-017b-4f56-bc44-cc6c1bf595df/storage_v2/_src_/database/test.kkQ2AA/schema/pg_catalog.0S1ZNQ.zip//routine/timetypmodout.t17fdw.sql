create function timetypmodout(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timetypmodout$$;

comment on function timetypmodout(integer) is 'I/O typmod';

alter function timetypmodout(integer) owner to marina;

