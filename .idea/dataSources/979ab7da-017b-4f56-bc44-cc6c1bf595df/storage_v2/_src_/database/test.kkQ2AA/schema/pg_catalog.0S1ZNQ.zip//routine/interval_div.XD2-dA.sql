create function interval_div(interval, double precision) returns interval
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$interval_div$$;

comment on function interval_div(interval, double precision) is 'implementation of / operator';

alter function interval_div(interval, double precision) owner to marina;

