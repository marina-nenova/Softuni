create function bpcharicregexne(character, text) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$texticregexne$$;

comment on function bpcharicregexne(char, text) is 'implementation of !~* operator';

alter function bpcharicregexne(char, text) owner to marina;

