create function has_function_privilege(name, text, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$has_function_privilege_name_name$$;

comment on function has_function_privilege(text, text, text) is 'current user privilege on function by function name';

alter function has_function_privilege(text, text, text) owner to marina;

