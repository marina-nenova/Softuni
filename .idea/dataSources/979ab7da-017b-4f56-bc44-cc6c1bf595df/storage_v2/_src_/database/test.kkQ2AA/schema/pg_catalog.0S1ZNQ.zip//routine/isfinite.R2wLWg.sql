create function isfinite(date) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_finite$$;

comment on function isfinite(timestamp with time zone) is 'finite timestamp?';

alter function isfinite(timestamp with time zone) owner to marina;

