create function numeric(money) returns numeric
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_numeric$$;

comment on function numeric(integer) is 'convert int4 to numeric';

alter function numeric(integer) owner to marina;

