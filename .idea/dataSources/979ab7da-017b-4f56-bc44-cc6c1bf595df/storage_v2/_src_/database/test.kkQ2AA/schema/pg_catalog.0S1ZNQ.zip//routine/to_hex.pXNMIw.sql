create function to_hex(bigint) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$to_hex64$$;

comment on function to_hex(bigint) is 'convert int8 number to hex';

alter function to_hex(bigint) owner to marina;

