create function dround(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dround$$;

comment on function dround(double precision) is 'round to nearest integer';

alter function dround(double precision) owner to marina;

