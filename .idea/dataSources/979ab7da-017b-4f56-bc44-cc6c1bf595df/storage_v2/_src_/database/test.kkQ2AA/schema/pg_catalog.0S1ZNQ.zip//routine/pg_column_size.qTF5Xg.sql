create function pg_column_size("any") returns integer
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_column_size$$;

comment on function pg_column_size("any") is 'bytes required to store the value, perhaps with compression';

alter function pg_column_size("any") owner to marina;

