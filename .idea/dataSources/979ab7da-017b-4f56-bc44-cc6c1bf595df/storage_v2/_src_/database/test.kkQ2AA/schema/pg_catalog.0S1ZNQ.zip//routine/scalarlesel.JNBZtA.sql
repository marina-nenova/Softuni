create function scalarlesel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$scalarlesel$$;

comment on function scalarlesel(internal, oid, internal, integer) is 'restriction selectivity of <= and related operators on scalar datatypes';

alter function scalarlesel(internal, oid, internal, integer) owner to marina;

