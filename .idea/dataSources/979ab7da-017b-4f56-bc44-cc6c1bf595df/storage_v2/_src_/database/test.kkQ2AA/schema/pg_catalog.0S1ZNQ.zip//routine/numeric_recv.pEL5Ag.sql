create function numeric_recv(internal, oid, integer) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$numeric_recv$$;

comment on function numeric_recv(internal, oid, integer) is 'I/O';

alter function numeric_recv(internal, oid, integer) owner to marina;

