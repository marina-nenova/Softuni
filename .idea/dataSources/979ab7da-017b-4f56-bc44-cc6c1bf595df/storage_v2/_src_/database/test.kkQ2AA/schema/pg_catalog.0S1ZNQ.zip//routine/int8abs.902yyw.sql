create function int8abs(bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int8abs$$;

comment on function int8abs(bigint) is 'implementation of @ operator';

alter function int8abs(bigint) owner to marina;

