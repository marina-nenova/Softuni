create function timestamptz_out(timestamp with time zone) returns cstring
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_out$$;

comment on function timestamptz_out(timestamp with time zone) is 'I/O';

alter function timestamptz_out(timestamp with time zone) owner to marina;

