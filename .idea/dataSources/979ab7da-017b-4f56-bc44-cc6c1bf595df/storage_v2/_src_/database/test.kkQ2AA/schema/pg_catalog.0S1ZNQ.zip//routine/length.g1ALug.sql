create function length(text) returns integer
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$textlen$$;

comment on function length(bytea, name) is 'length of string in specified encoding';

alter function length(bytea, name) owner to marina;

