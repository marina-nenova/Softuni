create function int2(double precision) returns smallint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dtoi2$$;

comment on function int2(bigint) is 'convert int8 to int2';

alter function int2(bigint) owner to marina;

