create function has_column_privilege(name, text, text, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$has_column_privilege_name_name_name$$;

comment on function has_column_privilege(name, oid, text, text) is 'user privilege on column by username, rel oid, col name';

alter function has_column_privilege(name, oid, text, text) owner to marina;

