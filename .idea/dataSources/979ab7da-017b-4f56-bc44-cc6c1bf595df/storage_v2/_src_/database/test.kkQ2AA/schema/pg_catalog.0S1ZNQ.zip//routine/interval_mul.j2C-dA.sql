create function interval_mul(interval, double precision) returns interval
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$interval_mul$$;

comment on function interval_mul(interval, double precision) is 'implementation of * operator';

alter function interval_mul(interval, double precision) owner to marina;

