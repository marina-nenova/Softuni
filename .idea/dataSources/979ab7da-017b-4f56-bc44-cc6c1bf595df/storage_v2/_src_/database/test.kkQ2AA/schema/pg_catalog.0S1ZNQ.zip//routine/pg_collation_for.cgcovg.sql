create function pg_collation_for("any") returns text
    stable
    parallel safe
    cost 1
    language internal
as
$$pg_collation_for$$;

comment on function pg_collation_for("any") is 'collation of the argument; implementation of the COLLATION FOR expression';

alter function pg_collation_for("any") owner to marina;

