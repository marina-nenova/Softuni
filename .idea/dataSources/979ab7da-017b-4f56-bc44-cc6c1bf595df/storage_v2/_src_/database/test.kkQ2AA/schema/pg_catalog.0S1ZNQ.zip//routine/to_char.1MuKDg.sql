create function to_char(timestamp with time zone, text) returns text
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_to_char$$;

comment on function to_char(integer, text) is 'format int4 to text';

alter function to_char(integer, text) owner to marina;

