create function int2up(smallint) returns smallint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int2up$$;

comment on function int2up(smallint) is 'implementation of + operator';

alter function int2up(smallint) owner to marina;

