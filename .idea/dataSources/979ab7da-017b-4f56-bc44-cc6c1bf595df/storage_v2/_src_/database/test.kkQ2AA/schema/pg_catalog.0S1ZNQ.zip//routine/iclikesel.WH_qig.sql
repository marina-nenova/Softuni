create function iclikesel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$iclikesel$$;

comment on function iclikesel(internal, oid, internal, integer) is 'restriction selectivity of ILIKE';

alter function iclikesel(internal, oid, internal, integer) owner to marina;

