create function abs(real) returns real
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float4abs$$;

comment on function abs(real) is 'absolute value';

alter function abs(real) owner to marina;

