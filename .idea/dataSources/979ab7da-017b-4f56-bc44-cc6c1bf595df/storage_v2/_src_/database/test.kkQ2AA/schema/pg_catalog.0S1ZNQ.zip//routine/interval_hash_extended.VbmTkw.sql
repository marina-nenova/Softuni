create function interval_hash_extended(interval, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$interval_hash_extended$$;

comment on function interval_hash_extended(interval, bigint) is 'hash';

alter function interval_hash_extended(interval, bigint) owner to marina;

