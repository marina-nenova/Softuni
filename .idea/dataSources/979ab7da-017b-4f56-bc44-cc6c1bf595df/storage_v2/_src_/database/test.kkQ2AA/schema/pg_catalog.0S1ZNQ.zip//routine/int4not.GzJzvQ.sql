create function int4not(integer) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int4not$$;

comment on function int4not(integer) is 'implementation of ~ operator';

alter function int4not(integer) owner to marina;

