create function nlikesel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$nlikesel$$;

comment on function nlikesel(internal, oid, internal, integer) is 'restriction selectivity of NOT LIKE';

alter function nlikesel(internal, oid, internal, integer) owner to marina;

