create function timetz_mi_interval(time with time zone, interval) returns time with time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timetz_mi_interval$$;

comment on function timetz_mi_interval(time with time zone, interval) is 'implementation of - operator';

alter function timetz_mi_interval(time with time zone, interval) owner to marina;

