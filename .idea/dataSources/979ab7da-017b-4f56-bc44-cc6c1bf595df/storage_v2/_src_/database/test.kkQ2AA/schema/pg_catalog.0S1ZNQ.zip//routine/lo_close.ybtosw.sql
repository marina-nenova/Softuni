create function lo_close(integer) returns integer
    strict
    cost 1
    language internal
as
$$be_lo_close$$;

comment on function lo_close(integer) is 'large object close';

alter function lo_close(integer) owner to marina;

