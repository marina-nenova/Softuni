create function circle(box) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_circle$$;

comment on function circle(polygon, float8) is 'convert polygon to circle';

alter function circle(polygon, float8) owner to marina;

