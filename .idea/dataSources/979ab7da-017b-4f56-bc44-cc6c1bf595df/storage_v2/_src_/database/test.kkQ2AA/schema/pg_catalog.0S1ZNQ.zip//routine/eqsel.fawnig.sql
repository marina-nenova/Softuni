create function eqsel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$eqsel$$;

comment on function eqsel(internal, oid, internal, integer) is 'restriction selectivity of = and related operators';

alter function eqsel(internal, oid, internal, integer) owner to marina;

