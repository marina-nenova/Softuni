create function int4up(integer) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int4up$$;

comment on function int4up(integer) is 'implementation of + operator';

alter function int4up(integer) owner to marina;

