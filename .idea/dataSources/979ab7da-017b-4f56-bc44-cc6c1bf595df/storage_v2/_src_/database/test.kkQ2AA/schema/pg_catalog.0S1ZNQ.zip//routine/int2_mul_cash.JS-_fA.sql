create function int2_mul_cash(smallint, money) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int2_mul_cash$$;

comment on function int2_mul_cash(smallint, money) is 'implementation of * operator';

alter function int2_mul_cash(smallint, money) owner to marina;

