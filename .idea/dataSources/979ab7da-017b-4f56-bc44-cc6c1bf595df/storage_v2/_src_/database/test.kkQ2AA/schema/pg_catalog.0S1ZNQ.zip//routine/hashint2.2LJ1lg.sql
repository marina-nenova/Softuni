create function hashint2(smallint) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashint2$$;

comment on function hashint2(smallint) is 'hash';

alter function hashint2(smallint) owner to marina;

