create function date_part(text, timestamp with time zone) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_part$$;

comment on function date_part(text, time with time zone) is 'extract field from time with time zone';

alter function date_part(text, time with time zone) owner to marina;

