create function name(text) returns name
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$text_name$$;

comment on function name(char) is 'convert char(n) to name';

alter function name(char) owner to marina;

