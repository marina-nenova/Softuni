create function current_schemas(boolean) returns name[]
    stable
    strict
    cost 1
    language internal
as
$$current_schemas$$;

comment on function current_schemas(boolean) is 'current schema search list';

alter function current_schemas(boolean) owner to marina;

