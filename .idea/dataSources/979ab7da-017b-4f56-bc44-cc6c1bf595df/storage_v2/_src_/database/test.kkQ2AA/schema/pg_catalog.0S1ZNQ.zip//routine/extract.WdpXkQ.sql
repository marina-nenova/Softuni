create function extract(text, timestamp with time zone) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$extract_timestamptz$$;

comment on function extract(text, time with time zone) is 'extract field from time with time zone';

alter function extract(text, time with time zone) owner to marina;

