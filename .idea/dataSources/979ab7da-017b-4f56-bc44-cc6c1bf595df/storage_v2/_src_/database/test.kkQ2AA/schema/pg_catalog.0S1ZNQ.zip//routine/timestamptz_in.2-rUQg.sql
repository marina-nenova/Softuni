create function timestamptz_in(cstring, oid, integer) returns timestamp with time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_in$$;

comment on function timestamptz_in(cstring, oid, integer) is 'I/O';

alter function timestamptz_in(cstring, oid, integer) owner to marina;

