create function "left"(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$text_left$$;

comment on function "left"(text, integer) is 'extract the first n characters';

alter function "left"(text, integer) owner to marina;

