create function hashmacaddrextended(macaddr, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashmacaddrextended$$;

comment on function hashmacaddrextended(macaddr, bigint) is 'hash';

alter function hashmacaddrextended(macaddr, bigint) owner to marina;

