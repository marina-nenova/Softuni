create function intervaltypmodin(cstring[]) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$intervaltypmodin$$;

comment on function intervaltypmodin(cstring[]) is 'I/O typmod';

alter function intervaltypmodin(cstring[]) owner to marina;

