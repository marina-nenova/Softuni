create function timestamptz_le_date(timestamp with time zone, date) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_le_date$$;

comment on function timestamptz_le_date(timestamp with time zone, date) is 'implementation of <= operator';

alter function timestamptz_le_date(timestamp with time zone, date) owner to marina;

