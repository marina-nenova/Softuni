create function cot(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcot$$;

comment on function cot(double precision) is 'cotangent';

alter function cot(double precision) owner to marina;

