create function polygon(box) returns polygon
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_poly$$;

comment on function polygon(integer, circle) is 'convert vertex count and circle to polygon';

alter function polygon(integer, circle) owner to marina;

