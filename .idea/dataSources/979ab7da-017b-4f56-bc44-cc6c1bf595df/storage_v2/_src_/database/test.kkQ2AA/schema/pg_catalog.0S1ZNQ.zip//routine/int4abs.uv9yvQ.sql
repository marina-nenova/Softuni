create function int4abs(integer) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int4abs$$;

comment on function int4abs(integer) is 'implementation of @ operator';

alter function int4abs(integer) owner to marina;

