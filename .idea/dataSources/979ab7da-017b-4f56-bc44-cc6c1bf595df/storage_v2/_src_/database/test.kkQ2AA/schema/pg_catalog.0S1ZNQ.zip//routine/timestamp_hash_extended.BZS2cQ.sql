create function timestamp_hash_extended(timestamp without time zone, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_hash_extended$$;

comment on function timestamp_hash_extended(timestamp, bigint) is 'hash';

alter function timestamp_hash_extended(timestamp, bigint) owner to marina;

