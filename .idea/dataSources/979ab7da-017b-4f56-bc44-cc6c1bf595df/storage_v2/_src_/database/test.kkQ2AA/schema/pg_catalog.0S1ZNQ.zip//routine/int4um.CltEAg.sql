create function int4um(integer) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int4um$$;

comment on function int4um(integer) is 'implementation of - operator';

alter function int4um(integer) owner to marina;

