create function areajoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$areajoinsel$$;

comment on function areajoinsel(internal, oid, internal, smallint, internal) is 'join selectivity for area-comparison operators';

alter function areajoinsel(internal, oid, internal, smallint, internal) owner to marina;

