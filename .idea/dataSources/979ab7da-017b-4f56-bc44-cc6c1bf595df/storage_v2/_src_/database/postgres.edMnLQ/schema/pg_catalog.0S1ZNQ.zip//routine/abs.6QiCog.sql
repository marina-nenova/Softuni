create function abs(real) returns real
    language internal
as
$$float4abs$$;

comment on function abs(float4) is 'absolute value';

