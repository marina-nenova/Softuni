create function contjoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$contjoinsel$$;

comment on function contjoinsel(internal, oid, internal, int2, internal) is 'join selectivity for containment comparison operators';

