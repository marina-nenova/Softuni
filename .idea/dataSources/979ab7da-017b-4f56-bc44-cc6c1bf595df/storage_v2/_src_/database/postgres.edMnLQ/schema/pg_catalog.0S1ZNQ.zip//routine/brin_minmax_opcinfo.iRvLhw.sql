create function brin_minmax_opcinfo(internal) returns internal
    language internal
as
$$brin_minmax_opcinfo$$;

comment on function brin_minmax_opcinfo(internal) is 'BRIN minmax support';

