create function cash_div_cash(money, money) returns double precision
    language internal
as
$$cash_div_cash$$;

comment on function cash_div_cash(money, money) is 'implementation of / operator';

