create function cidrecv(internal) returns cid
    language internal
as
$$cidrecv$$;

comment on function cidrecv(internal) is 'I/O';

