create function array_length(anyarray, integer) returns integer
    language internal
as
$$array_length$$;

comment on function array_length(anyarray, int4) is 'array length';

