create function anycompatible_out(anycompatible) returns cstring
    language internal
as
$$anycompatible_out$$;

comment on function anycompatible_out(anycompatible) is 'I/O';

