create function cosh(double precision) returns double precision
    language internal
as
$$dcosh$$;

comment on function cosh(float8) is 'hyperbolic cosine';

