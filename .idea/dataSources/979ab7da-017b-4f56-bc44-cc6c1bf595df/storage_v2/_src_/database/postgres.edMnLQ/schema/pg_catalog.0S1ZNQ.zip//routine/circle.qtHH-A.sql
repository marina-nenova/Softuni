create function circle(box) returns circle
    language internal
as
$$box_circle$$;

comment on function circle(box) is 'convert box to circle';

