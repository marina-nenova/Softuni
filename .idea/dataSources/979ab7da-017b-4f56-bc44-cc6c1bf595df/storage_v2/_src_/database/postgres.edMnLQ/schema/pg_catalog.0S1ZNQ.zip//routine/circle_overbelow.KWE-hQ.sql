create function circle_overbelow(circle, circle) returns boolean
    language internal
as
$$circle_overbelow$$;

comment on function circle_overbelow(circle, circle) is 'implementation of &<| operator';

