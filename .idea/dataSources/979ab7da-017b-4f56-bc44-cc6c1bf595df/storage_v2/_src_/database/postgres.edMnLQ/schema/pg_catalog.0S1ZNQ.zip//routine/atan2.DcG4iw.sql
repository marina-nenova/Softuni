create function atan2(double precision, double precision) returns double precision
    language internal
as
$$datan2$$;

comment on function atan2(float8, float8) is 'arctangent, two arguments';

