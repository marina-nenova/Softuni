create function cash_eq(money, money) returns boolean
    language internal
as
$$cash_eq$$;

comment on function cash_eq(money, money) is 'implementation of = operator';

