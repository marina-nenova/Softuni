create function byteane(bytea, bytea) returns boolean
    language internal
as
$$byteane$$;

comment on function byteane(bytea, bytea) is 'implementation of <> operator';

