create function byteaout(bytea) returns cstring
    language internal
as
$$byteaout$$;

comment on function byteaout(bytea) is 'I/O';

