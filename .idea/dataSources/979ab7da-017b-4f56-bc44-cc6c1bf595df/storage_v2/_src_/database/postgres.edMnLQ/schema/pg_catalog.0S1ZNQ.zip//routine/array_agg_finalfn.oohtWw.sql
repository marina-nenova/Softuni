create function array_agg_finalfn(internal, anynonarray) returns anyarray
    language internal
as
$$array_agg_finalfn$$;

comment on function array_agg_finalfn(internal, anynonarray) is 'aggregate final function';

