create function btrim(text) returns text
    language internal
as
$$btrim1$$;

comment on function btrim(text, text) is 'trim selected characters from both ends of string';

