create function "RI_FKey_check_ins"() returns trigger
    language internal
as
$$RI_FKey_check_ins$$;

comment on function "RI_FKey_check_ins"() is 'referential integrity FOREIGN KEY ... REFERENCES';

