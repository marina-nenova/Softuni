create function close_sl(lseg, line) returns point
    language internal
as
$$close_sl$$;

comment on function close_sl(lseg, line) is 'implementation of ## operator';

