create function convert_to(text, name) returns bytea
    language internal
as
$$pg_convert_to$$;

comment on function convert_to(text, name) is 'convert string with specified destination encoding name';

