create function cash_div_int2(money, smallint) returns money
    language internal
as
$$cash_div_int2$$;

comment on function cash_div_int2(money, int2) is 'implementation of / operator';

