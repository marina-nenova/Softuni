create function box_overlap(box, box) returns boolean
    language internal
as
$$box_overlap$$;

comment on function box_overlap(box, box) is 'implementation of && operator';

