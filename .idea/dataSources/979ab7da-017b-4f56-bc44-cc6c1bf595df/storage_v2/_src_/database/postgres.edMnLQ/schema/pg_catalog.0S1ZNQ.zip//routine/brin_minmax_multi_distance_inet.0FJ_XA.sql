create function brin_minmax_multi_distance_inet(internal, internal) returns double precision
    language internal
as
$$brin_minmax_multi_distance_inet$$;

comment on function brin_minmax_multi_distance_inet(internal, internal) is 'BRIN multi minmax inet distance';

