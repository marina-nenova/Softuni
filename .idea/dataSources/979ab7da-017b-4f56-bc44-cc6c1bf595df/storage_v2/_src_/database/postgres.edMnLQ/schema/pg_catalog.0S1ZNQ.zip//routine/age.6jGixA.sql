create function age(xid) returns integer
    language internal
as
$$xid_age$$;

comment on function age(timestamptz) is 'date difference from today preserving months and years';

