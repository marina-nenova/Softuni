create function array_subscript_handler(internal) returns internal
    language internal
as
$$array_subscript_handler$$;

comment on function array_subscript_handler(internal) is 'standard array subscripting support';

