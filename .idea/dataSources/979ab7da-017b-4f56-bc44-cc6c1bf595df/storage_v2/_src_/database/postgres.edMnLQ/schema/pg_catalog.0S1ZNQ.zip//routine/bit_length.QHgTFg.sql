create function bit_length(bytea) returns integer
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function bit_length(bytea) is 'length in bits';

