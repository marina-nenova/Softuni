create function btrim(text) returns text
    language internal
as
$$btrim1$$;

comment on function btrim(text) is 'trim spaces from both ends of string';

