create function charne("char", "char") returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$charne$$;

comment on function charne("char", "char") is 'implementation of <> operator';

alter function charne("char", "char") owner to marina;

