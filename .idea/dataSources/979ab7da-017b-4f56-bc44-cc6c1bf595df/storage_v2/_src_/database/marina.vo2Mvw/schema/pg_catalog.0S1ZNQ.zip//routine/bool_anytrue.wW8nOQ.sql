create function bool_anytrue(internal) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bool_anytrue$$;

comment on function bool_anytrue(internal) is 'aggregate final function';

alter function bool_anytrue(internal) owner to marina;

