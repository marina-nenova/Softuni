create function circle_gt(circle, circle) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_gt$$;

comment on function circle_gt(circle, circle) is 'implementation of > operator';

alter function circle_gt(circle, circle) owner to marina;

