create function atan2d(double precision, double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$datan2d$$;

comment on function atan2d(float8, float8) is 'arctangent, two arguments, degrees';

alter function atan2d(float8, float8) owner to marina;

