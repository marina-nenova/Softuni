create function circle_overabove(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_overabove$$;

comment on function circle_overabove(circle, circle) is 'implementation of |&> operator';

alter function circle_overabove(circle, circle) owner to marina;

