create function cidr_send(cidr) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidr_send$$;

comment on function cidr_send(cidr) is 'I/O';

alter function cidr_send(cidr) owner to marina;

