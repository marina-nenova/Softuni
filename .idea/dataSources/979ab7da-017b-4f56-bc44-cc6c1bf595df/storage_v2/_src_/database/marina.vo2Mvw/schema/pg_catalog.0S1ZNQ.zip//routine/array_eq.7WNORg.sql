create function array_eq(anyarray, anyarray) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_eq$$;

comment on function array_eq(anyarray, anyarray) is 'implementation of = operator';

alter function array_eq(anyarray, anyarray) owner to marina;

