create function brin_bloom_summary_recv(internal) returns pg_brin_bloom_summary
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_bloom_summary_recv$$;

comment on function brin_bloom_summary_recv(internal) is 'I/O';

alter function brin_bloom_summary_recv(internal) owner to marina;

