create function asin(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dasin$$;

comment on function asin(float8) is 'arcsine';

alter function asin(float8) owner to marina;

