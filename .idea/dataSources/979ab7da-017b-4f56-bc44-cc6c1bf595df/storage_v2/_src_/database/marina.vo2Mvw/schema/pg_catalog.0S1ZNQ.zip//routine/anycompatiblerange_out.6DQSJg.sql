create function anycompatiblerange_out(anycompatiblerange) returns cstring
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblerange_out$$;

comment on function anycompatiblerange_out(anycompatiblerange) is 'I/O';

alter function anycompatiblerange_out(anycompatiblerange) owner to marina;

