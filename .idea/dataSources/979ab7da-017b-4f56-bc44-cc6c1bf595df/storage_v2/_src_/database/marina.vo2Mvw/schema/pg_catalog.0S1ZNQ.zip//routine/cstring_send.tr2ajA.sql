create function cstring_send(cstring) returns bytea
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$cstring_send$$;

comment on function cstring_send(cstring) is 'I/O';

alter function cstring_send(cstring) owner to marina;

