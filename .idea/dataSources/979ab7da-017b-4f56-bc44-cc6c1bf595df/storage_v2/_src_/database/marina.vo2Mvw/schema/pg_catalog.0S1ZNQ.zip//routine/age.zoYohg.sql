create function age(xid) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$xid_age$$;

comment on function age(timestamp, timestamp) is 'date difference preserving months and years';

alter function age(timestamp, timestamp) owner to marina;

