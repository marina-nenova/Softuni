create function box_recv(internal) returns box
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_recv$$;

comment on function box_recv(internal) is 'I/O';

alter function box_recv(internal) owner to marina;

