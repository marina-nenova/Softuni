create function box_contained(box, box) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_contained$$;

comment on function box_contained(box, box) is 'implementation of <@ operator';

alter function box_contained(box, box) owner to marina;

