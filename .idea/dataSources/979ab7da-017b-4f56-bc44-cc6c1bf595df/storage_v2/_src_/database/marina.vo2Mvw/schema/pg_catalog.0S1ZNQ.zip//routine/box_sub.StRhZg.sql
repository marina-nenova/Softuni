create function box_sub(box, point) returns box
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_sub$$;

comment on function box_sub(box, point) is 'implementation of - operator';

alter function box_sub(box, point) owner to marina;

