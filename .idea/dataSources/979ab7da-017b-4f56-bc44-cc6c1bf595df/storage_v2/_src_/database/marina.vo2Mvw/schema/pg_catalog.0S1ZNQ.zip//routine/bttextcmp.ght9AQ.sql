create function bttextcmp(text, text) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bttextcmp$$;

comment on function bttextcmp(text, text) is 'less-equal-greater';

alter function bttextcmp(text, text) owner to marina;

