create function anycompatiblemultirange_out(anycompatiblemultirange) returns cstring
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblemultirange_out$$;

comment on function anycompatiblemultirange_out(anycompatiblemultirange) is 'I/O';

alter function anycompatiblemultirange_out(anycompatiblemultirange) owner to marina;

