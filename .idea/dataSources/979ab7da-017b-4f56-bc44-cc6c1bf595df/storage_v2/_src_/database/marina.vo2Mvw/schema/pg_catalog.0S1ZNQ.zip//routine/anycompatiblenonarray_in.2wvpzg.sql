create function anycompatiblenonarray_in(cstring) returns anycompatiblenonarray
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblenonarray_in$$;

comment on function anycompatiblenonarray_in(cstring) is 'I/O';

alter function anycompatiblenonarray_in(cstring) owner to marina;

