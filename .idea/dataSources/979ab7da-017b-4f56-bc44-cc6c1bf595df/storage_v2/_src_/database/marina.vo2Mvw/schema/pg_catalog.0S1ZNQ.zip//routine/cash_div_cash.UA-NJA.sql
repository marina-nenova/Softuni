create function cash_div_cash(money, money) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_div_cash$$;

comment on function cash_div_cash(money, money) is 'implementation of / operator';

alter function cash_div_cash(money, money) owner to marina;

