create function byteacat(bytea, bytea) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteacat$$;

comment on function byteacat(bytea, bytea) is 'implementation of || operator';

alter function byteacat(bytea, bytea) owner to marina;

