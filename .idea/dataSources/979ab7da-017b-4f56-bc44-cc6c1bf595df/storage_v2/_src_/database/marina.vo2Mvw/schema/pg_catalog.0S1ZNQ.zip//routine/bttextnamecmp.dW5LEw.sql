create function bttextnamecmp(text, name) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bttextnamecmp$$;

comment on function bttextnamecmp(text, name) is 'less-equal-greater';

alter function bttextnamecmp(text, name) owner to marina;

