create function array_send(anyarray) returns bytea
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_send$$;

comment on function array_send(anyarray) is 'I/O';

alter function array_send(anyarray) owner to marina;

