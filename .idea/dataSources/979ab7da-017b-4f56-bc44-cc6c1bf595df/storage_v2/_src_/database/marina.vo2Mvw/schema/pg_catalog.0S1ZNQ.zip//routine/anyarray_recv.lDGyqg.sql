create function anyarray_recv(internal) returns anyarray
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anyarray_recv$$;

comment on function anyarray_recv(internal) is 'I/O';

alter function anyarray_recv(internal) owner to marina;

