create function current_setting(text) returns text
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$show_config_by_name$$;

comment on function current_setting(text) is 'SHOW X as a function';

alter function current_setting(text) owner to marina;

