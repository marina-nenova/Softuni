create function boolor_statefunc(boolean, boolean) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$boolor_statefunc$$;

comment on function boolor_statefunc(bool, bool) is 'aggregate transition function';

alter function boolor_statefunc(bool, bool) owner to marina;

