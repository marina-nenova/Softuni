create function bpcharge(character, character) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bpcharge$$;

comment on function bpcharge(bpchar, bpchar) is 'implementation of >= operator';

alter function bpcharge(bpchar, bpchar) owner to marina;

