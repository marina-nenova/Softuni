create function circle_contained(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_contained$$;

comment on function circle_contained(circle, circle) is 'implementation of <@ operator';

alter function circle_contained(circle, circle) owner to marina;

