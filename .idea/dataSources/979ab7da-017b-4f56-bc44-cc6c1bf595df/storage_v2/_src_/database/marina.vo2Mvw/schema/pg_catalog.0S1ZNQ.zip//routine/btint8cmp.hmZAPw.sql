create function btint8cmp(bigint, bigint) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btint8cmp$$;

comment on function btint8cmp(int8, int8) is 'less-equal-greater';

alter function btint8cmp(int8, int8) owner to marina;

