create function asind(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dasind$$;

comment on function asind(float8) is 'arcsine, degrees';

alter function asind(float8) owner to marina;

