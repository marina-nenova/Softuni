create function amvalidate(oid) returns boolean
    strict
    parallel safe
    cost 1
    language internal
as
$$amvalidate$$;

comment on function amvalidate(oid) is 'validate an operator class';

alter function amvalidate(oid) owner to marina;

