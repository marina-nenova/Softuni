create function circle_div_pt(circle, point) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_div_pt$$;

comment on function circle_div_pt(circle, point) is 'implementation of / operator';

alter function circle_div_pt(circle, point) owner to marina;

