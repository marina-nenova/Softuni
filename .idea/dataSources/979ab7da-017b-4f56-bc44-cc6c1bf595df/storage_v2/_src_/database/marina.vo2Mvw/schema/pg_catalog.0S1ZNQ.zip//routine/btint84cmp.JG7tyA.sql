create function btint84cmp(bigint, integer) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btint84cmp$$;

comment on function btint84cmp(int8, int4) is 'less-equal-greater';

alter function btint84cmp(int8, int4) owner to marina;

