create function box_add(box, point) returns box
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_add$$;

comment on function box_add(box, point) is 'implementation of + operator';

alter function box_add(box, point) owner to marina;

