create function byteane(bytea, bytea) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$byteane$$;

comment on function byteane(bytea, bytea) is 'implementation of <> operator';

alter function byteane(bytea, bytea) owner to marina;

