create function btarraycmp(anyarray, anyarray) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btarraycmp$$;

comment on function btarraycmp(anyarray, anyarray) is 'less-equal-greater';

alter function btarraycmp(anyarray, anyarray) owner to marina;

