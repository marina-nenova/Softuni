create function current_setting(text) returns text
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$show_config_by_name$$;

comment on function current_setting(text, bool) is 'SHOW X as a function, optionally no error for missing variable';

alter function current_setting(text, bool) owner to marina;

