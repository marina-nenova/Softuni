create function btint4sortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btint4sortsupport$$;

comment on function btint4sortsupport(internal) is 'sort support';

alter function btint4sortsupport(internal) owner to marina;

