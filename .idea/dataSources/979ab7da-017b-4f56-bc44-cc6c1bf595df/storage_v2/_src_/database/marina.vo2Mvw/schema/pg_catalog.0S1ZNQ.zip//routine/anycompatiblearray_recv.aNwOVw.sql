create function anycompatiblearray_recv(internal) returns anycompatiblearray
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblearray_recv$$;

comment on function anycompatiblearray_recv(internal) is 'I/O';

alter function anycompatiblearray_recv(internal) owner to marina;

