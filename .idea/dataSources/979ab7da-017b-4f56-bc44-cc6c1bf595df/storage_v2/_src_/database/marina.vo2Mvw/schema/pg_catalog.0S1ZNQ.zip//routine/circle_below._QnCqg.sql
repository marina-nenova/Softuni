create function circle_below(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_below$$;

comment on function circle_below(circle, circle) is 'implementation of <<| operator';

alter function circle_below(circle, circle) owner to marina;

