create function bitgt(bit, bit) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bitgt$$;

comment on function bitgt(bit, bit) is 'implementation of > operator';

alter function bitgt(bit, bit) owner to marina;

