create function circle_contain(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_contain$$;

comment on function circle_contain(circle, circle) is 'implementation of @> operator';

alter function circle_contain(circle, circle) owner to marina;

