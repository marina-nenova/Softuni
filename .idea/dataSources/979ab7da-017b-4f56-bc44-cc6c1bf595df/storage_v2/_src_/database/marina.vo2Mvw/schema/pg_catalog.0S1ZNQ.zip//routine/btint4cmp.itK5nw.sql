create function btint4cmp(integer, integer) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btint4cmp$$;

comment on function btint4cmp(int4, int4) is 'less-equal-greater';

alter function btint4cmp(int4, int4) owner to marina;

