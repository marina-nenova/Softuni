create function atand(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$datand$$;

comment on function atand(float8) is 'arctangent, degrees';

alter function atand(float8) owner to marina;

