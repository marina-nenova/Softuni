create function btnamecmp(name, name) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btnamecmp$$;

comment on function btnamecmp(name, name) is 'less-equal-greater';

alter function btnamecmp(name, name) owner to marina;

