create function box(point, point) returns box
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$points_box$$;

comment on function box(polygon) is 'convert polygon to bounding box';

alter function box(polygon) owner to marina;

