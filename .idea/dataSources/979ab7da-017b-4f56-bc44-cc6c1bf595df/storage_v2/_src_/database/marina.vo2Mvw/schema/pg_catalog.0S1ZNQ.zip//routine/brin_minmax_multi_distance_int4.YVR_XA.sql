create function brin_minmax_multi_distance_int4(internal, internal) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_minmax_multi_distance_int4$$;

comment on function brin_minmax_multi_distance_int4(internal, internal) is 'BRIN multi minmax int4 distance';

alter function brin_minmax_multi_distance_int4(internal, internal) owner to marina;

