create function asinh(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dasinh$$;

comment on function asinh(float8) is 'inverse hyperbolic sine';

alter function asinh(float8) owner to marina;

