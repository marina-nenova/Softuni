create function brin_bloom_add_value(internal, internal, internal, internal) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_bloom_add_value$$;

comment on function brin_bloom_add_value(internal, internal, internal, internal) is 'BRIN bloom support';

alter function brin_bloom_add_value(internal, internal, internal, internal) owner to marina;

