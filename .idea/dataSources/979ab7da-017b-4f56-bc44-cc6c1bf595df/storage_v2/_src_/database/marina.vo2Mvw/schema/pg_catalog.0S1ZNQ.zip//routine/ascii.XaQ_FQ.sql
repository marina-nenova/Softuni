create function ascii(text) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$ascii$$;

comment on function ascii(text) is 'convert first char to int4';

alter function ascii(text) owner to marina;

