create function brin_bloom_summary_send(pg_brin_bloom_summary) returns bytea
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_bloom_summary_send$$;

comment on function brin_bloom_summary_send(pg_brin_bloom_summary) is 'I/O';

alter function brin_bloom_summary_send(pg_brin_bloom_summary) owner to marina;

