create function cos(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcos$$;

comment on function cos(float8) is 'cosine';

alter function cos(float8) owner to marina;

