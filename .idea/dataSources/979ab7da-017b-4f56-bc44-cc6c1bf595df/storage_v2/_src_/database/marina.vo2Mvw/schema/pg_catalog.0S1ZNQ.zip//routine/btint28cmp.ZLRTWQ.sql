create function btint28cmp(smallint, bigint) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btint28cmp$$;

comment on function btint28cmp(int2, int8) is 'less-equal-greater';

alter function btint28cmp(int2, int8) owner to marina;

