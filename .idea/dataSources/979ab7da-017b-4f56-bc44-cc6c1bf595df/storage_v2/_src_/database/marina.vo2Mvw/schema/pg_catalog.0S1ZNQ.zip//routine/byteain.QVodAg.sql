create function byteain(cstring) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteain$$;

comment on function byteain(cstring) is 'I/O';

alter function byteain(cstring) owner to marina;

