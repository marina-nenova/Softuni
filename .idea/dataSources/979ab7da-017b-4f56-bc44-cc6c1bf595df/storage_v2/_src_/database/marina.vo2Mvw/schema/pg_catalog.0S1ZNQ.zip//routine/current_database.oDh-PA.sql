create function current_database() returns name
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$current_database$$;

comment on function current_database() is 'name of the current database';

alter function current_database() owner to marina;

