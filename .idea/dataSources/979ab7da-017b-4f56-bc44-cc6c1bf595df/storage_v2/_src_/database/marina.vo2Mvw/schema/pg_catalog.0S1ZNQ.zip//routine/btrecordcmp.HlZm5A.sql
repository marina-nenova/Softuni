create function btrecordcmp(record, record) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btrecordcmp$$;

comment on function btrecordcmp(record, record) is 'less-equal-greater';

alter function btrecordcmp(record, record) owner to marina;

