create function brin_minmax_multi_summary_recv(internal) returns pg_brin_minmax_multi_summary
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_minmax_multi_summary_recv$$;

comment on function brin_minmax_multi_summary_recv(internal) is 'I/O';

alter function brin_minmax_multi_summary_recv(internal) owner to marina;

