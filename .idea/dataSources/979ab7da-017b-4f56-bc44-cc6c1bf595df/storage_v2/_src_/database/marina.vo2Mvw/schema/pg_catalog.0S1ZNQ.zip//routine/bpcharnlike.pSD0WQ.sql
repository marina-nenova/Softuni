create function bpcharnlike(character, text) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$textnlike$$;

comment on function bpcharnlike(bpchar, text) is 'implementation of !~~ operator';

alter function bpcharnlike(bpchar, text) owner to marina;

