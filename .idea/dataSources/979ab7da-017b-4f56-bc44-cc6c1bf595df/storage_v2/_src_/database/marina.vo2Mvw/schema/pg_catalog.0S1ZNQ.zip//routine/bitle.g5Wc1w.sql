create function bitle(bit, bit) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bitle$$;

comment on function bitle(bit, bit) is 'implementation of <= operator';

alter function bitle(bit, bit) owner to marina;

