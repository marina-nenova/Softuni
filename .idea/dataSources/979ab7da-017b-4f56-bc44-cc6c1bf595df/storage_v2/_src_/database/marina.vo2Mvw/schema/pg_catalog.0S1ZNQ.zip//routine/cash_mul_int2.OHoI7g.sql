create function cash_mul_int2(money, smallint) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_mul_int2$$;

comment on function cash_mul_int2(money, int2) is 'implementation of * operator';

alter function cash_mul_int2(money, int2) owner to marina;

