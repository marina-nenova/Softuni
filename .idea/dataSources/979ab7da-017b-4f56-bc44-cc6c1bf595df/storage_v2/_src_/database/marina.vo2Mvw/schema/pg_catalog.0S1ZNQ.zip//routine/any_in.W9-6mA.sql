create function any_in(cstring) returns "any"
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$any_in$$;

comment on function any_in(cstring) is 'I/O';

alter function any_in(cstring) owner to marina;

