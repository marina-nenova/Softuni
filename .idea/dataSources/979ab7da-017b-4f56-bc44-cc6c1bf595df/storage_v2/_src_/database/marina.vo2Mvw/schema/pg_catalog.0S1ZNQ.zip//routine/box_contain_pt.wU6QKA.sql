create function box_contain_pt(box, point) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_contain_pt$$;

comment on function box_contain_pt(box, point) is 'implementation of @> operator';

alter function box_contain_pt(box, point) owner to marina;

