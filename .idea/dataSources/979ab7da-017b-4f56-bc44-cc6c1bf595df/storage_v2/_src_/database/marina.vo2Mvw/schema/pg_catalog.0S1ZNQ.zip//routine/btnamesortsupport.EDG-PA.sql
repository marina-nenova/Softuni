create function btnamesortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btnamesortsupport$$;

comment on function btnamesortsupport(internal) is 'sort support';

alter function btnamesortsupport(internal) owner to marina;

