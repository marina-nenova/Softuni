create function btboolcmp(boolean, boolean) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btboolcmp$$;

comment on function btboolcmp(bool, bool) is 'less-equal-greater';

alter function btboolcmp(bool, bool) owner to marina;

