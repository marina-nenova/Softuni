create function bpchar_sortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchar_sortsupport$$;

comment on function bpchar_sortsupport(internal) is 'sort support';

alter function bpchar_sortsupport(internal) owner to marina;

