create function bpchargt(character, character) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchargt$$;

comment on function bpchargt(bpchar, bpchar) is 'implementation of > operator';

alter function bpchargt(bpchar, bpchar) owner to marina;

