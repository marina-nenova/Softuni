create function aclitemin(cstring) returns aclitem
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$aclitemin$$;

comment on function aclitemin(cstring) is 'I/O';

alter function aclitemin(cstring) owner to marina;

