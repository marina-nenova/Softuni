create function close_ps(point, lseg) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$close_ps$$;

comment on function close_ps(point, lseg) is 'implementation of ## operator';

alter function close_ps(point, lseg) owner to marina;

