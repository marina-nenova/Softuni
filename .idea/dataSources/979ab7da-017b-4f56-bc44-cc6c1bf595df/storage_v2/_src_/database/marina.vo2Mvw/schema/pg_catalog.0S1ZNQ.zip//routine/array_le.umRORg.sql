create function array_le(anyarray, anyarray) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_le$$;

comment on function array_le(anyarray, anyarray) is 'implementation of <= operator';

alter function array_le(anyarray, anyarray) owner to marina;

