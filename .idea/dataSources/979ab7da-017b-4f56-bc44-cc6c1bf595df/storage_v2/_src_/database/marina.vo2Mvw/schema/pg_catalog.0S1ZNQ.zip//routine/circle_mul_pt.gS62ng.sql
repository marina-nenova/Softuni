create function circle_mul_pt(circle, point) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_mul_pt$$;

comment on function circle_mul_pt(circle, point) is 'implementation of * operator';

alter function circle_mul_pt(circle, point) owner to marina;

