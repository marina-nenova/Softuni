create function boolgt(boolean, boolean) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$boolgt$$;

comment on function boolgt(bool, bool) is 'implementation of > operator';

alter function boolgt(bool, bool) owner to marina;

