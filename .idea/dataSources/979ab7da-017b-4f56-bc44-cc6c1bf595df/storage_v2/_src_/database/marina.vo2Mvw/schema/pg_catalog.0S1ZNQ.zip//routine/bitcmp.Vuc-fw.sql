create function bitcmp(bit, bit) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bitcmp$$;

comment on function bitcmp(bit, bit) is 'less-equal-greater';

alter function bitcmp(bit, bit) owner to marina;

