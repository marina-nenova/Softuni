create function array_agg_array_transfn(internal, anyarray) returns internal
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_agg_array_transfn$$;

comment on function array_agg_array_transfn(internal, anyarray) is 'aggregate transition function';

alter function array_agg_array_transfn(internal, anyarray) owner to marina;

