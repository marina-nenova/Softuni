create function close_pb(point, box) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$close_pb$$;

comment on function close_pb(point, box) is 'implementation of ## operator';

alter function close_pb(point, box) owner to marina;

