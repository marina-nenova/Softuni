create function circle_contain_pt(circle, point) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_contain_pt$$;

comment on function circle_contain_pt(circle, point) is 'implementation of @> operator';

alter function circle_contain_pt(circle, point) owner to marina;

