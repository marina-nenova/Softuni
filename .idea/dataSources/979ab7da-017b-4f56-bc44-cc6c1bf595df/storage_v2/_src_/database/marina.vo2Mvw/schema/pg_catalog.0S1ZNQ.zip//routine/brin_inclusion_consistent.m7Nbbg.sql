create function brin_inclusion_consistent(internal, internal, internal) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_inclusion_consistent$$;

comment on function brin_inclusion_consistent(internal, internal, internal) is 'BRIN inclusion support';

alter function brin_inclusion_consistent(internal, internal, internal) owner to marina;

