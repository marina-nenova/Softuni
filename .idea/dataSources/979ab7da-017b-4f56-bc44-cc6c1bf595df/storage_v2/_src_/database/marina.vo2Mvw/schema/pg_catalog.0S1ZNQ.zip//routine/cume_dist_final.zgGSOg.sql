create function cume_dist_final(internal, VARIADIC "any") returns double precision
    immutable
    parallel safe
    cost 1
    language internal
as
$$hypothetical_cume_dist_final$$;

comment on function cume_dist_final(internal, any) is 'aggregate final function';

alter function cume_dist_final(internal, any) owner to marina;

