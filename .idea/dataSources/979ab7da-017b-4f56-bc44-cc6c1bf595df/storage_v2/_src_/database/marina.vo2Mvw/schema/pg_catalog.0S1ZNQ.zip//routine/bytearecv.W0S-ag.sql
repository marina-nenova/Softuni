create function bytearecv(internal) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bytearecv$$;

comment on function bytearecv(internal) is 'I/O';

alter function bytearecv(internal) owner to marina;

