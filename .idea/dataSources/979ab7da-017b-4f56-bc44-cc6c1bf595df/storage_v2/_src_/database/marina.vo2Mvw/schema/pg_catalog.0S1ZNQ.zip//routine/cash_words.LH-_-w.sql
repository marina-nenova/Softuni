create function cash_words(money) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_words$$;

comment on function cash_words(money) is 'output money amount as words';

alter function cash_words(money) owner to marina;

