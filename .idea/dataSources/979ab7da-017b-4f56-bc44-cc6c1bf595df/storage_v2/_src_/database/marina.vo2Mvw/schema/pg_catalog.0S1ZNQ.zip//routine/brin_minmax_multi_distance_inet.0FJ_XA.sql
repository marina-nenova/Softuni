create function brin_minmax_multi_distance_inet(internal, internal) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_minmax_multi_distance_inet$$;

comment on function brin_minmax_multi_distance_inet(internal, internal) is 'BRIN multi minmax inet distance';

alter function brin_minmax_multi_distance_inet(internal, internal) owner to marina;

