create function area(path) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$path_area$$;

comment on function area(box) is 'box area';

alter function area(box) owner to marina;

