create function cidout(cid) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidout$$;

comment on function cidout(cid) is 'I/O';

alter function cidout(cid) owner to marina;

