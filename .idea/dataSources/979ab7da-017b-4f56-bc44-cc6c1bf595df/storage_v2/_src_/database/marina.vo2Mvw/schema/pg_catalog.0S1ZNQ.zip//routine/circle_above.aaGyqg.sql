create function circle_above(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_above$$;

comment on function circle_above(circle, circle) is 'implementation of |>> operator';

alter function circle_above(circle, circle) owner to marina;

