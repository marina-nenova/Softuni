create function btfloat84cmp(double precision, real) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btfloat84cmp$$;

comment on function btfloat84cmp(float8, float4) is 'less-equal-greater';

alter function btfloat84cmp(float8, float4) owner to marina;

