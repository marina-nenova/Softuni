create function circle_ge(circle, circle) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_ge$$;

comment on function circle_ge(circle, circle) is 'implementation of >= operator';

alter function circle_ge(circle, circle) owner to marina;

