create function btnametextcmp(name, text) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btnametextcmp$$;

comment on function btnametextcmp(name, text) is 'less-equal-greater';

alter function btnametextcmp(name, text) owner to marina;

