create function bytealt(bytea, bytea) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bytealt$$;

comment on function bytealt(bytea, bytea) is 'implementation of < operator';

alter function bytealt(bytea, bytea) owner to marina;

