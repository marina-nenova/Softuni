create function anycompatiblearray_send(anycompatiblearray) returns bytea
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblearray_send$$;

comment on function anycompatiblearray_send(anycompatiblearray) is 'I/O';

alter function anycompatiblearray_send(anycompatiblearray) owner to marina;

