create function bytea_sortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bytea_sortsupport$$;

comment on function bytea_sortsupport(internal) is 'sort support';

alter function bytea_sortsupport(internal) owner to marina;

