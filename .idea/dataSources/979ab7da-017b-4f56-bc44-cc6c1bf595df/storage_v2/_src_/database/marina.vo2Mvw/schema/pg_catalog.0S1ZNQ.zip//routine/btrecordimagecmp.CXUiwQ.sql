create function btrecordimagecmp(record, record) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btrecordimagecmp$$;

comment on function btrecordimagecmp(record, record) is 'less-equal-greater based on byte images';

alter function btrecordimagecmp(record, record) owner to marina;

