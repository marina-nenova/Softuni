create function bit(bigint, integer) returns bit
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bitfromint8$$;

comment on function bit(int8, int4) is 'convert int8 to bitstring';

alter function bit(int8, int4) owner to marina;

