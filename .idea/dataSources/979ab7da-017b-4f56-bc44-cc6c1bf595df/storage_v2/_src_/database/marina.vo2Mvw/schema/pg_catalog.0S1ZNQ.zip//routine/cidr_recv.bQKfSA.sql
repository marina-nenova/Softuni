create function cidr_recv(internal) returns cidr
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidr_recv$$;

comment on function cidr_recv(internal) is 'I/O';

alter function cidr_recv(internal) owner to marina;

