create function boolrecv(internal) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$boolrecv$$;

comment on function boolrecv(internal) is 'I/O';

alter function boolrecv(internal) owner to marina;

