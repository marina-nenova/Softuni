create function charle("char", "char") returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$charle$$;

comment on function charle("char", "char") is 'implementation of <= operator';

alter function charle("char", "char") owner to marina;

