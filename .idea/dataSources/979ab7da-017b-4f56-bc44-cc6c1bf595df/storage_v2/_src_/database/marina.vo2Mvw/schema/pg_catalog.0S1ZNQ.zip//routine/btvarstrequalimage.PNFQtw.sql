create function btvarstrequalimage(oid) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btvarstrequalimage$$;

comment on function btvarstrequalimage(oid) is 'equal image';

alter function btvarstrequalimage(oid) owner to marina;

