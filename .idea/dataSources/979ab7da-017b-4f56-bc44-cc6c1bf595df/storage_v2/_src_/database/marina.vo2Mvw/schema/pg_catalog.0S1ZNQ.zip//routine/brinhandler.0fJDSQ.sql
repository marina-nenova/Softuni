create function brinhandler(internal) returns index_am_handler
    strict
    parallel safe
    cost 1
    language internal
as
$$brinhandler$$;

comment on function brinhandler(internal) is 'brin index access method handler';

alter function brinhandler(internal) owner to marina;

