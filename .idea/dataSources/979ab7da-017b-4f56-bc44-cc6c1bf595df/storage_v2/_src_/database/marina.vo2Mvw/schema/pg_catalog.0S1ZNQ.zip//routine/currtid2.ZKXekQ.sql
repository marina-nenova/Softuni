create function currtid2(text, tid) returns tid
    strict
    cost 1
    language internal
as
$$currtid_byrelname$$;

comment on function currtid2(text, tid) is 'latest tid of a tuple';

alter function currtid2(text, tid) owner to marina;

