create function charge("char", "char") returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$charge$$;

comment on function charge("char", "char") is 'implementation of >= operator';

alter function charge("char", "char") owner to marina;

