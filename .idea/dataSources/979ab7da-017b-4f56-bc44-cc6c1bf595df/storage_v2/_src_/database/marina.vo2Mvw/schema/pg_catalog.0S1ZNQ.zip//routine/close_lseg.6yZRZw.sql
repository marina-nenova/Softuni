create function close_lseg(lseg, lseg) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$close_lseg$$;

comment on function close_lseg(lseg, lseg) is 'implementation of ## operator';

alter function close_lseg(lseg, lseg) owner to marina;

