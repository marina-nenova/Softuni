create function cideq(cid, cid) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cideq$$;

comment on function cideq(cid, cid) is 'implementation of = operator';

alter function cideq(cid, cid) owner to marina;

