create function brin_bloom_consistent(internal, internal, internal, integer) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_bloom_consistent$$;

comment on function brin_bloom_consistent(internal, internal, internal, int4) is 'BRIN bloom support';

alter function brin_bloom_consistent(internal, internal, internal, int4) owner to marina;

