create function aclitemeq(aclitem, aclitem) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$aclitem_eq$$;

comment on function aclitemeq(aclitem, aclitem) is 'implementation of = operator';

alter function aclitemeq(aclitem, aclitem) owner to marina;

