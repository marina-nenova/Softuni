create function anynonarray_out(anynonarray) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$anynonarray_out$$;

comment on function anynonarray_out(anynonarray) is 'I/O';

alter function anynonarray_out(anynonarray) owner to marina;

