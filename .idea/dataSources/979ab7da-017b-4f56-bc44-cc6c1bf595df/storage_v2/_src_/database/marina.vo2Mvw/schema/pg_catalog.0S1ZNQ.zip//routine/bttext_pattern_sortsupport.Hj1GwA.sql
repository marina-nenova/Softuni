create function bttext_pattern_sortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bttext_pattern_sortsupport$$;

comment on function bttext_pattern_sortsupport(internal) is 'sort support';

alter function bttext_pattern_sortsupport(internal) owner to marina;

