create function cash_mi(money, money) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_mi$$;

comment on function cash_mi(money, money) is 'implementation of - operator';

alter function cash_mi(money, money) owner to marina;

