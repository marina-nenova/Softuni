create function byteage(bytea, bytea) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$byteage$$;

comment on function byteage(bytea, bytea) is 'implementation of >= operator';

alter function byteage(bytea, bytea) owner to marina;

