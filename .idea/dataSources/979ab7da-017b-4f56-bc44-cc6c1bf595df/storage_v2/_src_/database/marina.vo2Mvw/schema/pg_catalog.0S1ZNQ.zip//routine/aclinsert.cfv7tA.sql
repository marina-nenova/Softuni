create function aclinsert(aclitem[], aclitem) returns aclitem[]
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$aclinsert$$;

comment on function aclinsert(_aclitem, aclitem) is 'add/update ACL item';

alter function aclinsert(_aclitem, aclitem) owner to marina;

