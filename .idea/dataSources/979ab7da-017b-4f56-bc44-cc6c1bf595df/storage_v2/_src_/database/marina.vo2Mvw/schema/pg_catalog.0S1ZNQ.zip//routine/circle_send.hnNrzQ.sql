create function circle_send(circle) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_send$$;

comment on function circle_send(circle) is 'I/O';

alter function circle_send(circle) owner to marina;

