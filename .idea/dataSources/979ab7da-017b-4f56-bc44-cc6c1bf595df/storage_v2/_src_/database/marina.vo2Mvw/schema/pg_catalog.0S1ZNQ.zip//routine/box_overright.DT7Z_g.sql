create function box_overright(box, box) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_overright$$;

comment on function box_overright(box, box) is 'implementation of &> operator';

alter function box_overright(box, box) owner to marina;

