create function aclremove(aclitem[], aclitem) returns aclitem[]
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$aclremove$$;

comment on function aclremove(_aclitem, aclitem) is 'remove ACL item';

alter function aclremove(_aclitem, aclitem) owner to marina;

