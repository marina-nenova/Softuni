create function array_remove(anycompatiblearray, anycompatible) returns anycompatiblearray
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_remove$$;

comment on function array_remove(anycompatiblearray, anycompatible) is 'remove any occurrences of an element from an array';

alter function array_remove(anycompatiblearray, anycompatible) owner to marina;

