create function btint8sortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btint8sortsupport$$;

comment on function btint8sortsupport(internal) is 'sort support';

alter function btint8sortsupport(internal) owner to marina;

