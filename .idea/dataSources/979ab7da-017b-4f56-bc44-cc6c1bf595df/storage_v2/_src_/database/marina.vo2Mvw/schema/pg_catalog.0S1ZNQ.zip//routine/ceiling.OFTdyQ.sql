create function ceiling(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dceil$$;

comment on function ceiling(float8) is 'nearest integer >= value';

alter function ceiling(float8) owner to marina;

