create function current_query() returns text
    parallel restricted
    cost 1
    language internal
as
$$current_query$$;

comment on function current_query() is 'get the currently executing query';

alter function current_query() owner to marina;

