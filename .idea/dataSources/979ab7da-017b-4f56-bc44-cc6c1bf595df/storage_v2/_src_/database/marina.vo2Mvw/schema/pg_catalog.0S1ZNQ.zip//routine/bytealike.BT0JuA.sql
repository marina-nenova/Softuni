create function bytealike(bytea, bytea) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bytealike$$;

comment on function bytealike(bytea, bytea) is 'implementation of ~~ operator';

alter function bytealike(bytea, bytea) owner to marina;

