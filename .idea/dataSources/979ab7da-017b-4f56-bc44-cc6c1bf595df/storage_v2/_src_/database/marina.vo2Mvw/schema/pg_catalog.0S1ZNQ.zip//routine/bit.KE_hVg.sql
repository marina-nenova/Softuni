create function bit(bigint, integer) returns bit
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bitfromint8$$;

comment on function bit(int4, int4) is 'convert int4 to bitstring';

alter function bit(int4, int4) owner to marina;

