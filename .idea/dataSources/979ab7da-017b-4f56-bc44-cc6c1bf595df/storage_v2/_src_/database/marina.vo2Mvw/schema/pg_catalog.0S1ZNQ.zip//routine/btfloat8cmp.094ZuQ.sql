create function btfloat8cmp(double precision, double precision) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btfloat8cmp$$;

comment on function btfloat8cmp(float8, float8) is 'less-equal-greater';

alter function btfloat8cmp(float8, float8) owner to marina;

