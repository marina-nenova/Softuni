create function bitxor(bit, bit) returns bit
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bitxor$$;

comment on function bitxor(bit, bit) is 'implementation of # operator';

alter function bitxor(bit, bit) owner to marina;

