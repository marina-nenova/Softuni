create function cidr_out(cidr) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidr_out$$;

comment on function cidr_out(cidr) is 'I/O';

alter function cidr_out(cidr) owner to marina;

