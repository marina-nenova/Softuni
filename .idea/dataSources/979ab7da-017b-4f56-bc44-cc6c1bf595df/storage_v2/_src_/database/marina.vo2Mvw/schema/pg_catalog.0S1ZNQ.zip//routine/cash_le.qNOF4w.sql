create function cash_le(money, money) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_le$$;

comment on function cash_le(money, money) is 'implementation of <= operator';

alter function cash_le(money, money) owner to marina;

