create function bpchar_pattern_lt(character, character) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchar_pattern_lt$$;

comment on function bpchar_pattern_lt(bpchar, bpchar) is 'implementation of ~<~ operator';

alter function bpchar_pattern_lt(bpchar, bpchar) owner to marina;

