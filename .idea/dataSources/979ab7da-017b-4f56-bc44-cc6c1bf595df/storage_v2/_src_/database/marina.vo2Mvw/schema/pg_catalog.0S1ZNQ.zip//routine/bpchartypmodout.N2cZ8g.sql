create function bpchartypmodout(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchartypmodout$$;

comment on function bpchartypmodout(int4) is 'I/O typmod';

alter function bpchartypmodout(int4) owner to marina;

