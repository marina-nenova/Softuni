create function circle_overright(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_overright$$;

comment on function circle_overright(circle, circle) is 'implementation of &> operator';

alter function circle_overright(circle, circle) owner to marina;

