create function anycompatiblerange_in(cstring, oid, integer) returns anycompatiblerange
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblerange_in$$;

comment on function anycompatiblerange_in(cstring, oid, int4) is 'I/O';

alter function anycompatiblerange_in(cstring, oid, int4) owner to marina;

