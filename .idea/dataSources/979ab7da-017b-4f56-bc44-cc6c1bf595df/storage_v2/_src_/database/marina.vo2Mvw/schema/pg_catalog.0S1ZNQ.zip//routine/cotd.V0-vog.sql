create function cotd(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcotd$$;

comment on function cotd(float8) is 'cotangent, degrees';

alter function cotd(float8) owner to marina;

