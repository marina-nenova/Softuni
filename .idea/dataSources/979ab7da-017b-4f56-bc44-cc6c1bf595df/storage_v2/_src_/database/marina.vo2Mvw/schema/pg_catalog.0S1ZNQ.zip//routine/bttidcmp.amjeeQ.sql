create function bttidcmp(tid, tid) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bttidcmp$$;

comment on function bttidcmp(tid, tid) is 'less-equal-greater';

alter function bttidcmp(tid, tid) owner to marina;

