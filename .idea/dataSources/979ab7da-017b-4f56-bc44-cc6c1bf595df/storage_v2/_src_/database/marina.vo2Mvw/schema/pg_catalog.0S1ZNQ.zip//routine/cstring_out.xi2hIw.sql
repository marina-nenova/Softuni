create function cstring_out(cstring) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cstring_out$$;

comment on function cstring_out(cstring) is 'I/O';

alter function cstring_out(cstring) owner to marina;

