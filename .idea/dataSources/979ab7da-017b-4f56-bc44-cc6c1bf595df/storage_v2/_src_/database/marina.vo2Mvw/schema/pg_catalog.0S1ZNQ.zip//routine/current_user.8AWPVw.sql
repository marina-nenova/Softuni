create function "current_user"() returns name
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$current_user$$;

comment on function "current_user"() is 'current user name';

alter function "current_user"() owner to marina;

