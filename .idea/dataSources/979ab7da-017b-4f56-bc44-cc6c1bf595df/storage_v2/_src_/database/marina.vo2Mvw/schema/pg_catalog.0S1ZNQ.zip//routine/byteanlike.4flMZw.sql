create function byteanlike(bytea, bytea) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteanlike$$;

comment on function byteanlike(bytea, bytea) is 'implementation of !~~ operator';

alter function byteanlike(bytea, bytea) owner to marina;

