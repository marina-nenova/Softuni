create function bpchareq(character, character) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchareq$$;

comment on function bpchareq(bpchar, bpchar) is 'implementation of = operator';

alter function bpchareq(bpchar, bpchar) owner to marina;

