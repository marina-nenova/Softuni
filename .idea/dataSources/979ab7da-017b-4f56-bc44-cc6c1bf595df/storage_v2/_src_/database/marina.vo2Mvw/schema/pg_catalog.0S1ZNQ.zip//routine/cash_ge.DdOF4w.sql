create function cash_ge(money, money) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_ge$$;

comment on function cash_ge(money, money) is 'implementation of >= operator';

alter function cash_ge(money, money) owner to marina;

