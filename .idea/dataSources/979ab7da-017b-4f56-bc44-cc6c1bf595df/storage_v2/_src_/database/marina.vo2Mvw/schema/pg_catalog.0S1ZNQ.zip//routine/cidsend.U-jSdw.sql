create function cidsend(cid) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidsend$$;

comment on function cidsend(cid) is 'I/O';

alter function cidsend(cid) owner to marina;

