create function circle_ne(circle, circle) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_ne$$;

comment on function circle_ne(circle, circle) is 'implementation of <> operator';

alter function circle_ne(circle, circle) owner to marina;

