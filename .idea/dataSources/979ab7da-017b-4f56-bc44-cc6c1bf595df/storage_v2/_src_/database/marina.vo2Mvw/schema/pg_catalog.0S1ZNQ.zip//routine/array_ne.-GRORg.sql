create function array_ne(anyarray, anyarray) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_ne$$;

comment on function array_ne(anyarray, anyarray) is 'implementation of <> operator';

alter function array_ne(anyarray, anyarray) owner to marina;

