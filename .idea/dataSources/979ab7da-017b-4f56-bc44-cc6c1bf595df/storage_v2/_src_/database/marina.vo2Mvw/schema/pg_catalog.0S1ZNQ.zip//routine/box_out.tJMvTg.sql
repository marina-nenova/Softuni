create function box_out(box) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_out$$;

comment on function box_out(box) is 'I/O';

alter function box_out(box) owner to marina;

