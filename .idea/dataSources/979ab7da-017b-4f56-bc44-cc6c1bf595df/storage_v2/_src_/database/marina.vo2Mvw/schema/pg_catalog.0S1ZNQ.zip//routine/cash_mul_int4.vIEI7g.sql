create function cash_mul_int4(money, integer) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_mul_int4$$;

comment on function cash_mul_int4(money, int4) is 'implementation of * operator';

alter function cash_mul_int4(money, int4) owner to marina;

