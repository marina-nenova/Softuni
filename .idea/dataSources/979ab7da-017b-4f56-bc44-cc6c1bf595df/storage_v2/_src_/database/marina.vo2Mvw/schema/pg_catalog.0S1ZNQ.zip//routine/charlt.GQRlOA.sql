create function charlt("char", "char") returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$charlt$$;

comment on function charlt("char", "char") is 'implementation of < operator';

alter function charlt("char", "char") owner to marina;

