create function cbrt(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcbrt$$;

comment on function cbrt(float8) is 'cube root';

alter function cbrt(float8) owner to marina;

