create function cardinality(anyarray) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_cardinality$$;

comment on function cardinality(anyarray) is 'array cardinality';

alter function cardinality(anyarray) owner to marina;

