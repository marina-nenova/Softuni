create function bitne(bit, bit) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bitne$$;

comment on function bitne(bit, bit) is 'implementation of <> operator';

alter function bitne(bit, bit) owner to marina;

