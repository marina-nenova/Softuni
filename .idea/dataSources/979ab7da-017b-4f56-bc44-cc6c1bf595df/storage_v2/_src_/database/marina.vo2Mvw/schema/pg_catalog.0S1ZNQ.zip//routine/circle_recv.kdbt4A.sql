create function circle_recv(internal) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_recv$$;

comment on function circle_recv(internal) is 'I/O';

alter function circle_recv(internal) owner to marina;

