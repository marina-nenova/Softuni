create function btint2cmp(smallint, smallint) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btint2cmp$$;

comment on function btint2cmp(int2, int2) is 'less-equal-greater';

alter function btint2cmp(int2, int2) owner to marina;

