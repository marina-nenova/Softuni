create function boolne(boolean, boolean) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$boolne$$;

comment on function boolne(bool, bool) is 'implementation of <> operator';

alter function boolne(bool, bool) owner to marina;

