create function btrim(text) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btrim1$$;

comment on function btrim(text) is 'trim spaces from both ends of string';

alter function btrim(text) owner to marina;

