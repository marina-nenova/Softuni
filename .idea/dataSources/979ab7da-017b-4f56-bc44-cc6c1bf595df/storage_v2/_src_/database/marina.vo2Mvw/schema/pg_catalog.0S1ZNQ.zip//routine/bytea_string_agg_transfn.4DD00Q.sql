create function bytea_string_agg_transfn(internal, bytea, bytea) returns internal
    immutable
    parallel safe
    cost 1
    language internal
as
$$bytea_string_agg_transfn$$;

comment on function bytea_string_agg_transfn(internal, bytea, bytea) is 'aggregate transition function';

alter function bytea_string_agg_transfn(internal, bytea, bytea) owner to marina;

