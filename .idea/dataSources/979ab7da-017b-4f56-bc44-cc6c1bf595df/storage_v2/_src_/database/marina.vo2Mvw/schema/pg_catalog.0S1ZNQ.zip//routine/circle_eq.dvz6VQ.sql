create function circle_eq(circle, circle) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_eq$$;

comment on function circle_eq(circle, circle) is 'implementation of = operator';

alter function circle_eq(circle, circle) owner to marina;

