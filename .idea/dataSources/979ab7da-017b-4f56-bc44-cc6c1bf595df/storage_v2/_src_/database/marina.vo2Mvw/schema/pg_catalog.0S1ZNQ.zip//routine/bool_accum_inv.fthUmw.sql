create function bool_accum_inv(internal, boolean) returns internal
    immutable
    parallel safe
    cost 1
    language internal
as
$$bool_accum_inv$$;

comment on function bool_accum_inv(internal, bool) is 'aggregate transition function';

alter function bool_accum_inv(internal, bool) owner to marina;

