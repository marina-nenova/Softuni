create function cash_gt(money, money) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_gt$$;

comment on function cash_gt(money, money) is 'implementation of > operator';

alter function cash_gt(money, money) owner to marina;

