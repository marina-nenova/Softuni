create function brin_minmax_multi_opcinfo(internal) returns internal
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_minmax_multi_opcinfo$$;

comment on function brin_minmax_multi_opcinfo(internal) is 'BRIN multi minmax support';

alter function brin_minmax_multi_opcinfo(internal) owner to marina;

