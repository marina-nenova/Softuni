create function anyarray_in(cstring) returns anyarray
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$anyarray_in$$;

comment on function anyarray_in(cstring) is 'I/O';

alter function anyarray_in(cstring) owner to marina;

