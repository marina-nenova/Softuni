create function charrecv(internal) returns "char"
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$charrecv$$;

comment on function charrecv(internal) is 'I/O';

alter function charrecv(internal) owner to marina;

