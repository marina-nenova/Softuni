create function byteale(bytea, bytea) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$byteale$$;

comment on function byteale(bytea, bytea) is 'implementation of <= operator';

alter function byteale(bytea, bytea) owner to marina;

