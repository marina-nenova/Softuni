create function booleq(boolean, boolean) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$booleq$$;

comment on function booleq(bool, bool) is 'implementation of = operator';

alter function booleq(bool, bool) owner to marina;

