create function array_to_tsvector(text[]) returns tsvector
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_to_tsvector$$;

comment on function array_to_tsvector(_text) is 'build tsvector from array of lexemes';

alter function array_to_tsvector(_text) owner to marina;

