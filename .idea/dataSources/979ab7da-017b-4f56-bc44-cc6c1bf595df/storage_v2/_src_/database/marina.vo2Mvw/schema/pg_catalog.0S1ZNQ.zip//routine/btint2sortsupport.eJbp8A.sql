create function btint2sortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btint2sortsupport$$;

comment on function btint2sortsupport(internal) is 'sort support';

alter function btint2sortsupport(internal) owner to marina;

