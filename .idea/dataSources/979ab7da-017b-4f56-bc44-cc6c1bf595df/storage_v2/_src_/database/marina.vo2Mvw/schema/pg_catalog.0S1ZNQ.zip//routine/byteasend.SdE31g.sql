create function byteasend(bytea) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteasend$$;

comment on function byteasend(bytea) is 'I/O';

alter function byteasend(bytea) owner to marina;

