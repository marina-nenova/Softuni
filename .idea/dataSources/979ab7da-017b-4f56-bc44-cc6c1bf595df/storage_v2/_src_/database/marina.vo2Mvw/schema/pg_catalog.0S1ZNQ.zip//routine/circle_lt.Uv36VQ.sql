create function circle_lt(circle, circle) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_lt$$;

comment on function circle_lt(circle, circle) is 'implementation of < operator';

alter function circle_lt(circle, circle) owner to marina;

