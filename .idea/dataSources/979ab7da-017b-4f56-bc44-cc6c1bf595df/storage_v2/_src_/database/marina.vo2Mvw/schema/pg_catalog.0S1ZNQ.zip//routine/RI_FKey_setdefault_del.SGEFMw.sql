create function "RI_FKey_setdefault_del"() returns trigger
    strict
    parallel safe
    cost 1
    language internal
as
$$RI_FKey_setdefault_del$$;

comment on function "RI_FKey_setdefault_del"() is 'referential integrity ON DELETE SET DEFAULT';

alter function "RI_FKey_setdefault_del"() owner to marina;

