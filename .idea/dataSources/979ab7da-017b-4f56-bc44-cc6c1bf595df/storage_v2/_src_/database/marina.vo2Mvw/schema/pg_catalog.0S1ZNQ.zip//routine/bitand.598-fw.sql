create function bitand(bit, bit) returns bit
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bit_and$$;

comment on function bitand(bit, bit) is 'implementation of & operator';

alter function bitand(bit, bit) owner to marina;

