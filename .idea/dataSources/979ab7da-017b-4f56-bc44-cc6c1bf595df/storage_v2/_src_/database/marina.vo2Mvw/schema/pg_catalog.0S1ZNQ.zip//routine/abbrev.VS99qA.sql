create function abbrev(cidr) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidr_abbrev$$;

comment on function abbrev(inet) is 'abbreviated display of inet value';

alter function abbrev(inet) owner to marina;

