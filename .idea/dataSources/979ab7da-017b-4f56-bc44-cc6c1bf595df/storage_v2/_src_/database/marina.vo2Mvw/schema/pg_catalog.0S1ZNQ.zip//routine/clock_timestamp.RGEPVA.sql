create function clock_timestamp() returns timestamp with time zone
    strict
    parallel safe
    cost 1
    language internal
as
$$clock_timestamp$$;

comment on function clock_timestamp() is 'current clock time';

alter function clock_timestamp() owner to marina;

