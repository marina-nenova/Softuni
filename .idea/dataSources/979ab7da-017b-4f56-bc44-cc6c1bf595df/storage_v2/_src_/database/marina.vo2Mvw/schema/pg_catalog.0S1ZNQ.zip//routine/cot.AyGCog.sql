create function cot(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcot$$;

comment on function cot(float8) is 'cotangent';

alter function cot(float8) owner to marina;

