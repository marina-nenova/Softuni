create function circle_distance(circle, circle) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_distance$$;

comment on function circle_distance(circle, circle) is 'implementation of <-> operator';

alter function circle_distance(circle, circle) owner to marina;

