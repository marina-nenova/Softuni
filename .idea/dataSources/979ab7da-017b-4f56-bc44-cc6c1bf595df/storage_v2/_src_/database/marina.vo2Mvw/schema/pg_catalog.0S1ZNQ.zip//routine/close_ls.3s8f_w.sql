create function close_ls(line, lseg) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$close_ls$$;

comment on function close_ls(line, lseg) is 'implementation of ## operator';

alter function close_ls(line, lseg) owner to marina;

