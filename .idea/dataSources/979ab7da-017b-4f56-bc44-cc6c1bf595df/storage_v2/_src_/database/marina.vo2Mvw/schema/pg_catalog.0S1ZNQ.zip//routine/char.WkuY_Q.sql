create function char(integer) returns "char"
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$i4tochar$$;

comment on function char(int4) is 'convert int4 to char';

alter function char(int4) owner to marina;

