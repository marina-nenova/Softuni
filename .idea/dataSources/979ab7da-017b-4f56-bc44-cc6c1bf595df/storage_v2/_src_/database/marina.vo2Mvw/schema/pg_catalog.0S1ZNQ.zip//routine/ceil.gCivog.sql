create function ceil(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dceil$$;

comment on function ceil(float8) is 'nearest integer >= value';

alter function ceil(float8) owner to marina;

