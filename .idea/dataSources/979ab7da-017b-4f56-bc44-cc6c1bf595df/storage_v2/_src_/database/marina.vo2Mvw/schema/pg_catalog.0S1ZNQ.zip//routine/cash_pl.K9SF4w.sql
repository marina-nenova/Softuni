create function cash_pl(money, money) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_pl$$;

comment on function cash_pl(money, money) is 'implementation of + operator';

alter function cash_pl(money, money) owner to marina;

