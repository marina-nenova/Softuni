create function byteaout(bytea) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteaout$$;

comment on function byteaout(bytea) is 'I/O';

alter function byteaout(bytea) owner to marina;

