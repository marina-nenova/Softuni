create function bpchar("char") returns character
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$char_bpchar$$;

comment on function bpchar("char") is 'convert char to char(n)';

alter function bpchar("char") owner to marina;

