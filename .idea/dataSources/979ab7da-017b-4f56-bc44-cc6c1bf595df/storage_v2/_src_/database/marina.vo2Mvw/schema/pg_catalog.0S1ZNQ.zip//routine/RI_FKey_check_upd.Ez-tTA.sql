create function "RI_FKey_check_upd"() returns trigger
    strict
    parallel safe
    cost 1
    language internal
as
$$RI_FKey_check_upd$$;

comment on function "RI_FKey_check_upd"() is 'referential integrity FOREIGN KEY ... REFERENCES';

alter function "RI_FKey_check_upd"() owner to marina;

