create function close_pl(point, line) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$close_pl$$;

comment on function close_pl(point, line) is 'implementation of ## operator';

alter function close_pl(point, line) owner to marina;

