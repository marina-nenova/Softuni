create function array_position(anycompatiblearray, anycompatible) returns integer
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_position$$;

comment on function array_position(anycompatiblearray, anycompatible) is 'returns an offset of value in array';

alter function array_position(anycompatiblearray, anycompatible) owner to marina;

