create function bpcharsend(character) returns bytea
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$bpcharsend$$;

comment on function bpcharsend(bpchar) is 'I/O';

alter function bpcharsend(bpchar) owner to marina;

