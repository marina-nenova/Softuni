create function cidrecv(internal) returns cid
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidrecv$$;

comment on function cidrecv(internal) is 'I/O';

alter function cidrecv(internal) owner to marina;

