create function brin_inclusion_union(internal, internal, internal) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_inclusion_union$$;

comment on function brin_inclusion_union(internal, internal, internal) is 'BRIN inclusion support';

alter function brin_inclusion_union(internal, internal, internal) owner to marina;

