create function bound_box(box, box) returns box
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$boxes_bound_box$$;

comment on function bound_box(box, box) is 'bounding box of two boxes';

alter function bound_box(box, box) owner to marina;

