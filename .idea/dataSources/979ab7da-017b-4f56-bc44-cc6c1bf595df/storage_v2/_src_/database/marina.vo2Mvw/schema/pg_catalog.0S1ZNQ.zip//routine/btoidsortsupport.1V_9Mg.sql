create function btoidsortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btoidsortsupport$$;

comment on function btoidsortsupport(internal) is 'sort support';

alter function btoidsortsupport(internal) owner to marina;

