create function close_lb(line, box) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$close_lb$$;

comment on function close_lb(line, box) is 'implementation of ## operator';

alter function close_lb(line, box) owner to marina;

