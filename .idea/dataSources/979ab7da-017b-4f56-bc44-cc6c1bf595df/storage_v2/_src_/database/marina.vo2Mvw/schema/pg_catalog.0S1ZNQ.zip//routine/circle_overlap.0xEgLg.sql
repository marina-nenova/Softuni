create function circle_overlap(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_overlap$$;

comment on function circle_overlap(circle, circle) is 'implementation of && operator';

alter function circle_overlap(circle, circle) owner to marina;

