create function btoidvectorcmp(oidvector, oidvector) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btoidvectorcmp$$;

comment on function btoidvectorcmp(oidvector, oidvector) is 'less-equal-greater';

alter function btoidvectorcmp(oidvector, oidvector) owner to marina;

