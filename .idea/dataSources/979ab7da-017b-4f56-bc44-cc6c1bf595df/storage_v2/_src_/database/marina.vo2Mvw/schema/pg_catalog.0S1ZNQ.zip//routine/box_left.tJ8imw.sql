create function box_left(box, box) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_left$$;

comment on function box_left(box, box) is 'implementation of << operator';

alter function box_left(box, box) owner to marina;

