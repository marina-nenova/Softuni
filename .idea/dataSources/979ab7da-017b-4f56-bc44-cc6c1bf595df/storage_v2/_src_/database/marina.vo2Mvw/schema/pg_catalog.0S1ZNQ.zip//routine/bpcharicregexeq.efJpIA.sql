create function bpcharicregexeq(character, text) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$texticregexeq$$;

comment on function bpcharicregexeq(bpchar, text) is 'implementation of ~* operator';

alter function bpcharicregexeq(bpchar, text) owner to marina;

