create function char(integer) returns "char"
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$i4tochar$$;

comment on function char(text) is 'convert text to char';

alter function char(text) owner to marina;

