create function cash_recv(internal) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_recv$$;

comment on function cash_recv(internal) is 'I/O';

alter function cash_recv(internal) owner to marina;

