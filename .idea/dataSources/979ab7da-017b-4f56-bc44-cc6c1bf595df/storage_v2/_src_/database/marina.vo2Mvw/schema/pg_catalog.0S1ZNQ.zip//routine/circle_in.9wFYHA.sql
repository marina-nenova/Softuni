create function circle_in(cstring) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_in$$;

comment on function circle_in(cstring) is 'I/O';

alter function circle_in(cstring) owner to marina;

