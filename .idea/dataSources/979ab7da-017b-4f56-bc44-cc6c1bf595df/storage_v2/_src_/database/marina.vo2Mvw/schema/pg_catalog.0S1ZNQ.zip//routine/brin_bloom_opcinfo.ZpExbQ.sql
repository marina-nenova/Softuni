create function brin_bloom_opcinfo(internal) returns internal
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_bloom_opcinfo$$;

comment on function brin_bloom_opcinfo(internal) is 'BRIN bloom support';

alter function brin_bloom_opcinfo(internal) owner to marina;

