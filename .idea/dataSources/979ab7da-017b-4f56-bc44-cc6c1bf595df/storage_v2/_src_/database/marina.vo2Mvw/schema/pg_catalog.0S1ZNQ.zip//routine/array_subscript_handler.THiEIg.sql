create function array_subscript_handler(internal) returns internal
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_subscript_handler$$;

comment on function array_subscript_handler(internal) is 'standard array subscripting support';

alter function array_subscript_handler(internal) owner to marina;

