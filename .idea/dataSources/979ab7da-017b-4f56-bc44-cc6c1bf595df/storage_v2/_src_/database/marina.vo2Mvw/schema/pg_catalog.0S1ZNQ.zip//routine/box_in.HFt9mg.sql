create function box_in(cstring) returns box
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_in$$;

comment on function box_in(cstring) is 'I/O';

alter function box_in(cstring) owner to marina;

