create function circle_overbelow(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_overbelow$$;

comment on function circle_overbelow(circle, circle) is 'implementation of &<| operator';

alter function circle_overbelow(circle, circle) owner to marina;

