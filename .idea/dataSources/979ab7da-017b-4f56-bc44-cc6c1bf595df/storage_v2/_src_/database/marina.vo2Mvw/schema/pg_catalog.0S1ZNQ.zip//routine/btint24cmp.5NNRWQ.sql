create function btint24cmp(smallint, integer) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btint24cmp$$;

comment on function btint24cmp(int2, int4) is 'less-equal-greater';

alter function btint24cmp(int2, int4) owner to marina;

