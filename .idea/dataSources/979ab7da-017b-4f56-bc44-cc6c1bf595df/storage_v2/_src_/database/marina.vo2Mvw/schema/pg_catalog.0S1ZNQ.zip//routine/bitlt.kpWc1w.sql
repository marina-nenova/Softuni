create function bitlt(bit, bit) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bitlt$$;

comment on function bitlt(bit, bit) is 'implementation of < operator';

alter function bitlt(bit, bit) owner to marina;

