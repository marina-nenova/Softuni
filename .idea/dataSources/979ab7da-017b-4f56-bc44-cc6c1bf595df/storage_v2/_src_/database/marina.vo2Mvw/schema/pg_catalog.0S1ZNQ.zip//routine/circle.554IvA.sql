create function circle(box) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_circle$$;

comment on function circle(point, float8) is 'convert point and radius to circle';

alter function circle(point, float8) owner to marina;

