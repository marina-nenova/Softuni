create function anyelement_out(anyelement) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$anyelement_out$$;

comment on function anyelement_out(anyelement) is 'I/O';

alter function anyelement_out(anyelement) owner to marina;

