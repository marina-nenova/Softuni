create function bpchar_smaller(character, character) returns character
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchar_smaller$$;

comment on function bpchar_smaller(bpchar, bpchar) is 'smaller of two';

alter function bpchar_smaller(bpchar, bpchar) owner to marina;

