create function byteacmp(bytea, bytea) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$byteacmp$$;

comment on function byteacmp(bytea, bytea) is 'less-equal-greater';

alter function byteacmp(bytea, bytea) owner to marina;

