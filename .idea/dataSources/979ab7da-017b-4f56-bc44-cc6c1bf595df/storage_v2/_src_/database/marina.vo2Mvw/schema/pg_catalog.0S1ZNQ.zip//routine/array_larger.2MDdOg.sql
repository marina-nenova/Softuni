create function array_larger(anyarray, anyarray) returns anyarray
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_larger$$;

comment on function array_larger(anyarray, anyarray) is 'larger of two';

alter function array_larger(anyarray, anyarray) owner to marina;

