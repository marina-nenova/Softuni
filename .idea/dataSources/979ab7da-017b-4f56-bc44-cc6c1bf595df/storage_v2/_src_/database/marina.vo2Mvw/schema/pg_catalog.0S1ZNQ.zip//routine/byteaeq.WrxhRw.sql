create function byteaeq(bytea, bytea) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$byteaeq$$;

comment on function byteaeq(bytea, bytea) is 'implementation of = operator';

alter function byteaeq(bytea, bytea) owner to marina;

