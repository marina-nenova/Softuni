create function arraycontains(anyarray, anyarray) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$arraycontains$$;

comment on function arraycontains(anyarray, anyarray) is 'implementation of @> operator';

alter function arraycontains(anyarray, anyarray) owner to marina;

