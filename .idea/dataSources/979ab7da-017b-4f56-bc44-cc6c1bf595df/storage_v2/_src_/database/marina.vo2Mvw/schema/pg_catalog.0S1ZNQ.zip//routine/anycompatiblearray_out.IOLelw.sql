create function anycompatiblearray_out(anycompatiblearray) returns cstring
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblearray_out$$;

comment on function anycompatiblearray_out(anycompatiblearray) is 'I/O';

alter function anycompatiblearray_out(anycompatiblearray) owner to marina;

