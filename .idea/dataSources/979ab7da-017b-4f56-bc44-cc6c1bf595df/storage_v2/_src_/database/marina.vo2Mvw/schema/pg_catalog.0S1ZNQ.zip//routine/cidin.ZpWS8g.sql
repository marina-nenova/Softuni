create function cidin(cstring) returns cid
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidin$$;

comment on function cidin(cstring) is 'I/O';

alter function cidin(cstring) owner to marina;

