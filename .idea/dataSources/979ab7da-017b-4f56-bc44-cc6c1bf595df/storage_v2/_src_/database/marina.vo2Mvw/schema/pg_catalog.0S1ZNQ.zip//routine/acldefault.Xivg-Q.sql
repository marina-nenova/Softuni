create function acldefault("char", oid) returns aclitem[]
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$acldefault_sql$$;

comment on function acldefault("char", oid) is 'show hardwired default privileges, primarily for use by the information schema';

alter function acldefault("char", oid) owner to marina;

