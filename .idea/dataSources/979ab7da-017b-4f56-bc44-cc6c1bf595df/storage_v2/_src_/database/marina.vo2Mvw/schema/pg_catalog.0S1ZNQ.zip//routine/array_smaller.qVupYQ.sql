create function array_smaller(anyarray, anyarray) returns anyarray
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_smaller$$;

comment on function array_smaller(anyarray, anyarray) is 'smaller of two';

alter function array_smaller(anyarray, anyarray) owner to marina;

