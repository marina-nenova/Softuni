create function atan(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$datan$$;

comment on function atan(float8) is 'arctangent';

alter function atan(float8) owner to marina;

