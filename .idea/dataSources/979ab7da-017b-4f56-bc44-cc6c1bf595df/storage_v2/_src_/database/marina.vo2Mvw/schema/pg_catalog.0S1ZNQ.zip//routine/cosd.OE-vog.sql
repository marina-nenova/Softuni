create function cosd(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcosd$$;

comment on function cosd(float8) is 'cosine, degrees';

alter function cosd(float8) owner to marina;

