create function aclcontains(aclitem[], aclitem) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$aclcontains$$;

comment on function aclcontains(_aclitem, aclitem) is 'contains';

alter function aclcontains(_aclitem, aclitem) owner to marina;

