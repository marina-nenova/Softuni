create function btint82cmp(bigint, smallint) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btint82cmp$$;

comment on function btint82cmp(int8, int2) is 'less-equal-greater';

alter function btint82cmp(int8, int2) owner to marina;

