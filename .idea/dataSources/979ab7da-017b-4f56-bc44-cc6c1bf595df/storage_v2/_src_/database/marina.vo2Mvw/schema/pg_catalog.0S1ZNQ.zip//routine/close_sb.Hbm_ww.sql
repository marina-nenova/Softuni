create function close_sb(lseg, box) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$close_sb$$;

comment on function close_sb(lseg, box) is 'implementation of ## operator';

alter function close_sb(lseg, box) owner to marina;

