create function brin_minmax_union(internal, internal, internal) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_minmax_union$$;

comment on function brin_minmax_union(internal, internal, internal) is 'BRIN minmax support';

alter function brin_minmax_union(internal, internal, internal) owner to marina;

