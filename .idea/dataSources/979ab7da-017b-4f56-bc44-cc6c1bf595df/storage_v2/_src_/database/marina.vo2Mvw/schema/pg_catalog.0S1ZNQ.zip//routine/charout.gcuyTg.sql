create function charout("char") returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$charout$$;

comment on function charout("char") is 'I/O';

alter function charout("char") owner to marina;

