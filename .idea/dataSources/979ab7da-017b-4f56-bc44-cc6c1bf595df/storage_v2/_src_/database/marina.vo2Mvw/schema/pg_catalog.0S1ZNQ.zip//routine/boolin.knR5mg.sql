create function boolin(cstring) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$boolin$$;

comment on function boolin(cstring) is 'I/O';

alter function boolin(cstring) owner to marina;

