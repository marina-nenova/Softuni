create function circle_same(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_same$$;

comment on function circle_same(circle, circle) is 'implementation of ~= operator';

alter function circle_same(circle, circle) owner to marina;

