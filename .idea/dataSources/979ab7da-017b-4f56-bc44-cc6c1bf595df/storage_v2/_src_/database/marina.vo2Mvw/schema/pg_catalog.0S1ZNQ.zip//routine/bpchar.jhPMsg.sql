create function bpchar("char") returns character
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$char_bpchar$$;

comment on function bpchar(name) is 'convert name to char(n)';

alter function bpchar(name) owner to marina;

