create function array_recv(internal, oid, integer) returns anyarray
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_recv$$;

comment on function array_recv(internal, oid, int4) is 'I/O';

alter function array_recv(internal, oid, int4) owner to marina;

