create function boollt(boolean, boolean) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$boollt$$;

comment on function boollt(bool, bool) is 'implementation of < operator';

alter function boollt(bool, bool) owner to marina;

