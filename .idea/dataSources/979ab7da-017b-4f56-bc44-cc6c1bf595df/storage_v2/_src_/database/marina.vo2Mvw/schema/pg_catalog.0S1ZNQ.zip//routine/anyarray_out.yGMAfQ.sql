create function anyarray_out(anyarray) returns cstring
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anyarray_out$$;

comment on function anyarray_out(anyarray) is 'I/O';

alter function anyarray_out(anyarray) owner to marina;

