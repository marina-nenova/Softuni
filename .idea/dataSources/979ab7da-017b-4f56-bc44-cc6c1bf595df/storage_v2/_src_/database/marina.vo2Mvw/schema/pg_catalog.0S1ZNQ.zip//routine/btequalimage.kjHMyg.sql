create function btequalimage(oid) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btequalimage$$;

comment on function btequalimage(oid) is 'equal image';

alter function btequalimage(oid) owner to marina;

