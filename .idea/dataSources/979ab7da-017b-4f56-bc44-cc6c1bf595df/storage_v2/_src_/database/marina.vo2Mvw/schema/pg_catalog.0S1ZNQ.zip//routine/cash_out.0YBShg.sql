create function cash_out(money) returns cstring
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_out$$;

comment on function cash_out(money) is 'I/O';

alter function cash_out(money) owner to marina;

