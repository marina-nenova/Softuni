create function box_overleft(box, box) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_overleft$$;

comment on function box_overleft(box, box) is 'implementation of &< operator';

alter function box_overleft(box, box) owner to marina;

