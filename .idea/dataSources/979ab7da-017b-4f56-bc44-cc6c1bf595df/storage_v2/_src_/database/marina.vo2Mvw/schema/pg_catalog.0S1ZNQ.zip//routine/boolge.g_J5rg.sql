create function boolge(boolean, boolean) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$boolge$$;

comment on function boolge(bool, bool) is 'implementation of >= operator';

alter function boolge(bool, bool) owner to marina;

