create function box_div(box, point) returns box
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_div$$;

comment on function box_div(box, point) is 'implementation of / operator';

alter function box_div(box, point) owner to marina;

