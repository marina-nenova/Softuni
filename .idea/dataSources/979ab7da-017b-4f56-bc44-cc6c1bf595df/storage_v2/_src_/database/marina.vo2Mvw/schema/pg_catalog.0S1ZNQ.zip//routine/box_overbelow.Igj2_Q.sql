create function box_overbelow(box, box) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_overbelow$$;

comment on function box_overbelow(box, box) is 'implementation of &<| operator';

alter function box_overbelow(box, box) owner to marina;

