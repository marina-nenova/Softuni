create function btint48cmp(integer, bigint) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btint48cmp$$;

comment on function btint48cmp(int4, int8) is 'less-equal-greater';

alter function btint48cmp(int4, int8) owner to marina;

