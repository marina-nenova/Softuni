create function btcharcmp("char", "char") returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btcharcmp$$;

comment on function btcharcmp("char", "char") is 'less-equal-greater';

alter function btcharcmp("char", "char") owner to marina;

