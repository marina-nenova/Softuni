create function chr(integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$chr$$;

comment on function chr(int4) is 'convert int4 to char';

alter function chr(int4) owner to marina;

