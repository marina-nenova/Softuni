create function "current_schema"() returns name
    stable
    strict
    cost 1
    language internal
as
$$current_schema$$;

comment on function "current_schema"() is 'current schema name';

alter function "current_schema"() owner to marina;

