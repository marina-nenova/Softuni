create function bernoulli(internal) returns tsm_handler
    strict
    parallel safe
    cost 1
    language internal
as
$$tsm_bernoulli_handler$$;

comment on function bernoulli(internal) is 'BERNOULLI tablesample method handler';

alter function bernoulli(internal) owner to marina;

