create function brin_minmax_multi_distance_timestamp(internal, internal) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_minmax_multi_distance_timestamp$$;

comment on function brin_minmax_multi_distance_timestamp(internal, internal) is 'BRIN multi minmax timestamp distance';

alter function brin_minmax_multi_distance_timestamp(internal, internal) owner to marina;

