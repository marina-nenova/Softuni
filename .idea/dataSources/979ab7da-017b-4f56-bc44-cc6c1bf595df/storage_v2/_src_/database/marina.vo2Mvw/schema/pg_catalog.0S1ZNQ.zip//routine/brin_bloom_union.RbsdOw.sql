create function brin_bloom_union(internal, internal, internal) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_bloom_union$$;

comment on function brin_bloom_union(internal, internal, internal) is 'BRIN bloom support';

alter function brin_bloom_union(internal, internal, internal) owner to marina;

