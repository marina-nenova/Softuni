create function box_center(box) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_center$$;

comment on function box_center(box) is 'implementation of @@ operator';

alter function box_center(box) owner to marina;

