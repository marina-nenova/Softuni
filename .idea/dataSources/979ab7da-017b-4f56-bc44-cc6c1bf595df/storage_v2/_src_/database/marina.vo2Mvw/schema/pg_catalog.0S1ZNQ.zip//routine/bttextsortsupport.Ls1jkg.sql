create function bttextsortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bttextsortsupport$$;

comment on function bttextsortsupport(internal) is 'sort support';

alter function bttextsortsupport(internal) owner to marina;

