create function byteagt(bytea, bytea) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$byteagt$$;

comment on function byteagt(bytea, bytea) is 'implementation of > operator';

alter function byteagt(bytea, bytea) owner to marina;

