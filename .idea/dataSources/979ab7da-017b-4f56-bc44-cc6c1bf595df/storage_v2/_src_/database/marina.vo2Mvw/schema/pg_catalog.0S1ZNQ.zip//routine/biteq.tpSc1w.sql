create function biteq(bit, bit) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$biteq$$;

comment on function biteq(bit, bit) is 'implementation of = operator';

alter function biteq(bit, bit) owner to marina;

