create function btbpchar_pattern_cmp(character, character) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btbpchar_pattern_cmp$$;

comment on function btbpchar_pattern_cmp(bpchar, bpchar) is 'less-equal-greater';

alter function btbpchar_pattern_cmp(bpchar, bpchar) owner to marina;

