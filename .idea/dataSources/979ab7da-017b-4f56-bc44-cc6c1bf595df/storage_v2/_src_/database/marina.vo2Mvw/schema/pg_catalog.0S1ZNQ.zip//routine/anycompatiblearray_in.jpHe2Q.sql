create function anycompatiblearray_in(cstring) returns anycompatiblearray
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatiblearray_in$$;

comment on function anycompatiblearray_in(cstring) is 'I/O';

alter function anycompatiblearray_in(cstring) owner to marina;

