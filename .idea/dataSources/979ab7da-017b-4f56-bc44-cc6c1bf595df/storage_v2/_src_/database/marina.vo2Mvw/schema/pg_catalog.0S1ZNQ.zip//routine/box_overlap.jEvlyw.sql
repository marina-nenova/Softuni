create function box_overlap(box, box) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_overlap$$;

comment on function box_overlap(box, box) is 'implementation of && operator';

alter function box_overlap(box, box) owner to marina;

