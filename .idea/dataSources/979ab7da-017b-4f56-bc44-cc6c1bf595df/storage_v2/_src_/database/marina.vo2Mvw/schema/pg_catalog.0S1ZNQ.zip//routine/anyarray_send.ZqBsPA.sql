create function anyarray_send(anyarray) returns bytea
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anyarray_send$$;

comment on function anyarray_send(anyarray) is 'I/O';

alter function anyarray_send(anyarray) owner to marina;

