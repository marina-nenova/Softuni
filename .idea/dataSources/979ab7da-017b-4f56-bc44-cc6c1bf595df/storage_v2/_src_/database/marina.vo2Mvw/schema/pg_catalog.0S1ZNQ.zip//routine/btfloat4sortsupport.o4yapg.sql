create function btfloat4sortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btfloat4sortsupport$$;

comment on function btfloat4sortsupport(internal) is 'sort support';

alter function btfloat4sortsupport(internal) owner to marina;

