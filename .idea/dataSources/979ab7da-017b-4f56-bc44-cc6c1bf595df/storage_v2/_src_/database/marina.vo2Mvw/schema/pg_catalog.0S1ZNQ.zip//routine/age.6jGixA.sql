create function age(xid) returns integer
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$xid_age$$;

comment on function age(timestamptz) is 'date difference from today preserving months and years';

alter function age(timestamptz) owner to marina;

