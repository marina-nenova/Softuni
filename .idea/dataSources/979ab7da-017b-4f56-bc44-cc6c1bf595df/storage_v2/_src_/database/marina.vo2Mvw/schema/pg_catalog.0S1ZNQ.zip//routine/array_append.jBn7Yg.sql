create function array_append(anycompatiblearray, anycompatible) returns anycompatiblearray
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_append$$;

comment on function array_append(anycompatiblearray, anycompatible) is 'append element onto end of array';

alter function array_append(anycompatiblearray, anycompatible) owner to marina;

