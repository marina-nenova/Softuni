create function array_typanalyze(internal) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_typanalyze$$;

comment on function array_typanalyze(internal) is 'array typanalyze';

alter function array_typanalyze(internal) owner to marina;

