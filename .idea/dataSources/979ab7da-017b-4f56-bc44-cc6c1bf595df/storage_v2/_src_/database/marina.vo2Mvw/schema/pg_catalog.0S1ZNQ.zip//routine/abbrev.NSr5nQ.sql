create function abbrev(cidr) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidr_abbrev$$;

comment on function abbrev(cidr) is 'abbreviated display of cidr value';

alter function abbrev(cidr) owner to marina;

