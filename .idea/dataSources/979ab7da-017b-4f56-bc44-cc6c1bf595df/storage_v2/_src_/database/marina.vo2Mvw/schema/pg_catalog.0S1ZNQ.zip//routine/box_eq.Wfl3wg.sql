create function box_eq(box, box) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_eq$$;

comment on function box_eq(box, box) is 'implementation of = operator';

alter function box_eq(box, box) owner to marina;

