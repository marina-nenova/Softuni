create function bit_out(bit) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bit_out$$;

comment on function bit_out(bit) is 'I/O';

alter function bit_out(bit) owner to marina;

