create function convert_to(text, name) returns bytea
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_convert_to$$;

comment on function convert_to(text, name) is 'convert string with specified destination encoding name';

alter function convert_to(text, name) owner to marina;

