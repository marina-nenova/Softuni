create function btrim(text) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btrim1$$;

comment on function btrim(bytea, bytea) is 'trim selected bytes from both ends of string';

alter function btrim(bytea, bytea) owner to marina;

