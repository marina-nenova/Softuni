create function bttext_pattern_cmp(text, text) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bttext_pattern_cmp$$;

comment on function bttext_pattern_cmp(text, text) is 'less-equal-greater';

alter function bttext_pattern_cmp(text, text) owner to marina;

