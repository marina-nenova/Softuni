create function cash_send(money) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_send$$;

comment on function cash_send(money) is 'I/O';

alter function cash_send(money) owner to marina;

