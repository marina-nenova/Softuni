create function brin_minmax_multi_consistent(internal, internal, internal, integer) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_minmax_multi_consistent$$;

comment on function brin_minmax_multi_consistent(internal, internal, internal, int4) is 'BRIN multi minmax support';

alter function brin_minmax_multi_consistent(internal, internal, internal, int4) owner to marina;

