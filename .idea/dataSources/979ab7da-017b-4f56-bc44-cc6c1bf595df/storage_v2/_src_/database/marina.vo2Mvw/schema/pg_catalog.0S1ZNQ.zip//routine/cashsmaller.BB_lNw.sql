create function cashsmaller(money, money) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cashsmaller$$;

comment on function cashsmaller(money, money) is 'smaller of two';

alter function cashsmaller(money, money) owner to marina;

