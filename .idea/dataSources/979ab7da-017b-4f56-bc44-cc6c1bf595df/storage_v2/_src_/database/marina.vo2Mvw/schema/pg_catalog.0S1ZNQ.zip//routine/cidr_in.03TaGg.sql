create function cidr_in(cstring) returns cidr
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidr_in$$;

comment on function cidr_in(cstring) is 'I/O';

alter function cidr_in(cstring) owner to marina;

