create function array_positions(anycompatiblearray, anycompatible) returns integer[]
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_positions$$;

comment on function array_positions(anycompatiblearray, anycompatible) is 'returns an array of offsets of some value in array';

alter function array_positions(anycompatiblearray, anycompatible) owner to marina;

