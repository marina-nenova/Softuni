create function areasel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$areasel$$;

comment on function areasel(internal, oid, internal, int4) is 'restriction selectivity for area-comparison operators';

alter function areasel(internal, oid, internal, int4) owner to marina;

