create function acosd(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dacosd$$;

comment on function acosd(float8) is 'arccosine, degrees';

alter function acosd(float8) owner to marina;

