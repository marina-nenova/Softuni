create function array_dims(anyarray) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_dims$$;

comment on function array_dims(anyarray) is 'array dimensions';

alter function array_dims(anyarray) owner to marina;

