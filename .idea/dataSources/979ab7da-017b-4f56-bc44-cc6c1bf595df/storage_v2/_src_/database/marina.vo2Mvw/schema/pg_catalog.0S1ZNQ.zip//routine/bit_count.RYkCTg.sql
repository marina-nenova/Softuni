create function bit_count(bytea) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bytea_bit_count$$;

comment on function bit_count(bytea) is 'number of set bits';

alter function bit_count(bytea) owner to marina;

