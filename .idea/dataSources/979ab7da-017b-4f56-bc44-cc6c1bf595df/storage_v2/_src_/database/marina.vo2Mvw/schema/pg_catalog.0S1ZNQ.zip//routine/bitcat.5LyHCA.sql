create function bitcat(bit varying, bit varying) returns bit varying
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bitcat$$;

comment on function bitcat(varbit, varbit) is 'implementation of || operator';

alter function bitcat(varbit, varbit) owner to marina;

