create function anymultirange_out(anymultirange) returns cstring
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anymultirange_out$$;

comment on function anymultirange_out(anymultirange) is 'I/O';

alter function anymultirange_out(anymultirange) owner to marina;

