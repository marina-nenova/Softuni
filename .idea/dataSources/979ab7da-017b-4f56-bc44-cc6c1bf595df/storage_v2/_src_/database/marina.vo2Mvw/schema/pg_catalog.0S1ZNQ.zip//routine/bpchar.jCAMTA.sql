create function bpchar("char") returns character
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$char_bpchar$$;

comment on function bpchar(bpchar, int4, bool) is 'adjust char() to typmod length';

alter function bpchar(bpchar, int4, bool) owner to marina;

