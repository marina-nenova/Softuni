create function array_to_json(anyarray) returns json
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_to_json$$;

comment on function array_to_json(anyarray) is 'map array to json';

alter function array_to_json(anyarray) owner to marina;

