create function charin(cstring) returns "char"
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$charin$$;

comment on function charin(cstring) is 'I/O';

alter function charin(cstring) owner to marina;

