create function btoidcmp(oid, oid) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btoidcmp$$;

comment on function btoidcmp(oid, oid) is 'less-equal-greater';

alter function btoidcmp(oid, oid) owner to marina;

