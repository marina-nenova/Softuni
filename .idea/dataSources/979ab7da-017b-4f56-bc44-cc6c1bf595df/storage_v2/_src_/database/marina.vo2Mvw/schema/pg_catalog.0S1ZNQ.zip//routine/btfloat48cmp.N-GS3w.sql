create function btfloat48cmp(real, double precision) returns integer
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$btfloat48cmp$$;

comment on function btfloat48cmp(float4, float8) is 'less-equal-greater';

alter function btfloat48cmp(float4, float8) owner to marina;

