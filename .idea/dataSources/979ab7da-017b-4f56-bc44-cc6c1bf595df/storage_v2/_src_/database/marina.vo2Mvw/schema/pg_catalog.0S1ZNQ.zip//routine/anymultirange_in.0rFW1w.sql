create function anymultirange_in(cstring, oid, integer) returns anymultirange
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anymultirange_in$$;

comment on function anymultirange_in(cstring, oid, int4) is 'I/O';

alter function anymultirange_in(cstring, oid, int4) owner to marina;

