create function arrayoverlap(anyarray, anyarray) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$arrayoverlap$$;

comment on function arrayoverlap(anyarray, anyarray) is 'implementation of && operator';

alter function arrayoverlap(anyarray, anyarray) owner to marina;

