create function box_lt(box, box) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_lt$$;

comment on function box_lt(box, box) is 'implementation of < operator';

alter function box_lt(box, box) owner to marina;

