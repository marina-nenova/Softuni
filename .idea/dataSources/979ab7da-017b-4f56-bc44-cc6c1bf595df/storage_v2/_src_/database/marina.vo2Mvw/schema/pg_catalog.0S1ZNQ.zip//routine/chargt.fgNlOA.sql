create function chargt("char", "char") returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$chargt$$;

comment on function chargt("char", "char") is 'implementation of > operator';

alter function chargt("char", "char") owner to marina;

