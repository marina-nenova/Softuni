create function charsend("char") returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$charsend$$;

comment on function charsend("char") is 'I/O';

alter function charsend("char") owner to marina;

