create function anynonarray_in(cstring) returns anynonarray
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$anynonarray_in$$;

comment on function anynonarray_in(cstring) is 'I/O';

alter function anynonarray_in(cstring) owner to marina;

