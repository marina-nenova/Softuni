create function array_ge(anyarray, anyarray) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_ge$$;

comment on function array_ge(anyarray, anyarray) is 'implementation of >= operator';

alter function array_ge(anyarray, anyarray) owner to marina;

