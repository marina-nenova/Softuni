create function bthandler(internal) returns index_am_handler
    strict
    parallel safe
    cost 1
    language internal
as
$$bthandler$$;

comment on function bthandler(internal) is 'btree index access method handler';

alter function bthandler(internal) owner to marina;

