create function cstring_recv(internal) returns cstring
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$cstring_recv$$;

comment on function cstring_recv(internal) is 'I/O';

alter function cstring_recv(internal) owner to marina;

