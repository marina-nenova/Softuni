create function bpcharlt(character, character) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bpcharlt$$;

comment on function bpcharlt(bpchar, bpchar) is 'implementation of < operator';

alter function bpcharlt(bpchar, bpchar) owner to marina;

