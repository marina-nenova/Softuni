create function broadcast(inet) returns inet
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$network_broadcast$$;

comment on function broadcast(inet) is 'broadcast address of network';

alter function broadcast(inet) owner to marina;

