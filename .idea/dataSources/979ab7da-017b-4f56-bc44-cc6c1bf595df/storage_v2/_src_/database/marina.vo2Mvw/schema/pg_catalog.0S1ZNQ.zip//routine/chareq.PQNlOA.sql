create function chareq("char", "char") returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$chareq$$;

comment on function chareq("char", "char") is 'implementation of = operator';

alter function chareq("char", "char") owner to marina;

