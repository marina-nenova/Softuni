create function brin_bloom_options(internal) returns void
    immutable
    parallel safe
    cost 1
    language internal
as
$$brin_bloom_options$$;

comment on function brin_bloom_options(internal) is 'BRIN bloom support';

alter function brin_bloom_options(internal) owner to marina;

