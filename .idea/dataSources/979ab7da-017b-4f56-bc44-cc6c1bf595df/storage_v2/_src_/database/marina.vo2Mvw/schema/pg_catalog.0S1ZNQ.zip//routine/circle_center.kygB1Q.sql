create function circle_center(circle) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_center$$;

comment on function circle_center(circle) is 'implementation of @@ operator';

alter function circle_center(circle) owner to marina;

