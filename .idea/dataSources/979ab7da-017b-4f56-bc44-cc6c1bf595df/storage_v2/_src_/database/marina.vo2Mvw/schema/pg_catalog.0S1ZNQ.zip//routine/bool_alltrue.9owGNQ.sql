create function bool_alltrue(internal) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bool_alltrue$$;

comment on function bool_alltrue(internal) is 'aggregate final function';

alter function bool_alltrue(internal) owner to marina;

