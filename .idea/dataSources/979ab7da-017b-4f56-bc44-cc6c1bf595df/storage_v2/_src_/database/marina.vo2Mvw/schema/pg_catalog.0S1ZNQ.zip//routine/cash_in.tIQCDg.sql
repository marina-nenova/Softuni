create function cash_in(cstring) returns money
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_in$$;

comment on function cash_in(cstring) is 'I/O';

alter function cash_in(cstring) owner to marina;

