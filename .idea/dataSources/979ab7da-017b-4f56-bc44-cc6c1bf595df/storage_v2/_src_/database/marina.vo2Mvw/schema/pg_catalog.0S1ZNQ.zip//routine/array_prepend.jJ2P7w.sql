create function array_prepend(anycompatible, anycompatiblearray) returns anycompatiblearray
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_prepend$$;

comment on function array_prepend(anycompatible, anycompatiblearray) is 'prepend element onto front of array';

alter function array_prepend(anycompatible, anycompatiblearray) owner to marina;

