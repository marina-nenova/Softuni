create function cidr(inet) returns cidr
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$inet_to_cidr$$;

comment on function cidr(inet) is 'convert inet to cidr';

alter function cidr(inet) owner to marina;

