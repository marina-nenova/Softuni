create function area(path) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$path_area$$;

comment on function area(circle) is 'area of circle';

alter function area(circle) owner to marina;

