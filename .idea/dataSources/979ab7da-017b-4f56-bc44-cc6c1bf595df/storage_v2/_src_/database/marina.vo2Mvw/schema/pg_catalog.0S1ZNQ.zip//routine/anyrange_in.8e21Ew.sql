create function anyrange_in(cstring, oid, integer) returns anyrange
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$anyrange_in$$;

comment on function anyrange_in(cstring, oid, int4) is 'I/O';

alter function anyrange_in(cstring, oid, int4) owner to marina;

