create function cstring_in(cstring) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cstring_in$$;

comment on function cstring_in(cstring) is 'I/O';

alter function cstring_in(cstring) owner to marina;

