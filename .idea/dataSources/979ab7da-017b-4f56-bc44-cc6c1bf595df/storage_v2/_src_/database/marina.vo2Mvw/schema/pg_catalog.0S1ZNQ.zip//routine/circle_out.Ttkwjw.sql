create function circle_out(circle) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_out$$;

comment on function circle_out(circle) is 'I/O';

alter function circle_out(circle) owner to marina;

