create function convert(bytea, name, name) returns bytea
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_convert$$;

comment on function convert(bytea, name, name) is 'convert string with specified encoding names';

alter function convert(bytea, name, name) owner to marina;

