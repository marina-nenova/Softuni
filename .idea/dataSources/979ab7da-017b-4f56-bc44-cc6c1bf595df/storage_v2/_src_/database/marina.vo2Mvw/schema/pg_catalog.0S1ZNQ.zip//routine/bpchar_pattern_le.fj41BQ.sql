create function bpchar_pattern_le(character, character) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchar_pattern_le$$;

comment on function bpchar_pattern_le(bpchar, bpchar) is 'implementation of ~<=~ operator';

alter function bpchar_pattern_le(bpchar, bpchar) owner to marina;

