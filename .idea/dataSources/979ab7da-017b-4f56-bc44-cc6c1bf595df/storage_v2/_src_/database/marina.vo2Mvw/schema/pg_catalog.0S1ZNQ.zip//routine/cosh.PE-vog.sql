create function cosh(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dcosh$$;

comment on function cosh(float8) is 'hyperbolic cosine';

alter function cosh(float8) owner to marina;

