create function anyelement_in(cstring) returns anyelement
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$anyelement_in$$;

comment on function anyelement_in(cstring) is 'I/O';

alter function anyelement_in(cstring) owner to marina;

