create function brin_minmax_multi_distance_date(internal, internal) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_minmax_multi_distance_date$$;

comment on function brin_minmax_multi_distance_date(internal, internal) is 'BRIN multi minmax date distance';

alter function brin_minmax_multi_distance_date(internal, internal) owner to marina;

