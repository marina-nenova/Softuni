create function bpchar_larger(character, character) returns character
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchar_larger$$;

comment on function bpchar_larger(bpchar, bpchar) is 'larger of two';

alter function bpchar_larger(bpchar, bpchar) owner to marina;

