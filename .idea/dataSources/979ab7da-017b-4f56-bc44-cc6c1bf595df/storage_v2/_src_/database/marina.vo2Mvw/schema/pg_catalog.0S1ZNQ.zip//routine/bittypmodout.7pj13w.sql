create function bittypmodout(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bittypmodout$$;

comment on function bittypmodout(int4) is 'I/O typmod';

alter function bittypmodout(int4) owner to marina;

