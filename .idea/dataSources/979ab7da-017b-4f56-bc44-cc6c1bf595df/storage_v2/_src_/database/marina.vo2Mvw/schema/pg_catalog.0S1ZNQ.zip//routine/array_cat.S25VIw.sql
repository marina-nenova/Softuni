create function array_cat(anycompatiblearray, anycompatiblearray) returns anycompatiblearray
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_cat$$;

comment on function array_cat(anycompatiblearray, anycompatiblearray) is 'implementation of || operator';

alter function array_cat(anycompatiblearray, anycompatiblearray) owner to marina;

