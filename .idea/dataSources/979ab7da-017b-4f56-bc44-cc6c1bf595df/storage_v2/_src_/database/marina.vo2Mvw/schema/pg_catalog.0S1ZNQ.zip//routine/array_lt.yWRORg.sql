create function array_lt(anyarray, anyarray) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$array_lt$$;

comment on function array_lt(anyarray, anyarray) is 'implementation of < operator';

alter function array_lt(anyarray, anyarray) owner to marina;

