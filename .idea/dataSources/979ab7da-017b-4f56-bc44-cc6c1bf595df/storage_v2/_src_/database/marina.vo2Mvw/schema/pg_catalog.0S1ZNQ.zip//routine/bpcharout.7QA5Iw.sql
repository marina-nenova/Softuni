create function bpcharout(character) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bpcharout$$;

comment on function bpcharout(bpchar) is 'I/O';

alter function bpcharout(bpchar) owner to marina;

