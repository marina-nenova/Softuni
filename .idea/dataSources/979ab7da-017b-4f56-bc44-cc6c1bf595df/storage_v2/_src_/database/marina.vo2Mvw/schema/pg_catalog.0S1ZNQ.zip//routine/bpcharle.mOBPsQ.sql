create function bpcharle(character, character) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bpcharle$$;

comment on function bpcharle(bpchar, bpchar) is 'implementation of <= operator';

alter function bpcharle(bpchar, bpchar) owner to marina;

