create function anycompatible_out(anycompatible) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$anycompatible_out$$;

comment on function anycompatible_out(anycompatible) is 'I/O';

alter function anycompatible_out(anycompatible) owner to marina;

