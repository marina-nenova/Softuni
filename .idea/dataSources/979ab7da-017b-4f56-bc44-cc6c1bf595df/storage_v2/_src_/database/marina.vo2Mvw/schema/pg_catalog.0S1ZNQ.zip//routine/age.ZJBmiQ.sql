create function age(xid) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$xid_age$$;

comment on function age(timestamp) is 'date difference from today preserving months and years';

alter function age(timestamp) owner to marina;

