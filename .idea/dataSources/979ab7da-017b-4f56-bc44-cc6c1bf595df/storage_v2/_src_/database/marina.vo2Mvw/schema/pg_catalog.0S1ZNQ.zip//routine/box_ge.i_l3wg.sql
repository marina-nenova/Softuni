create function box_ge(box, box) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_ge$$;

comment on function box_ge(box, box) is 'implementation of >= operator';

alter function box_ge(box, box) owner to marina;

