create function bitge(bit, bit) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$bitge$$;

comment on function bitge(bit, bit) is 'implementation of >= operator';

alter function bitge(bit, bit) owner to marina;

