create function btfloat8sortsupport(internal) returns void
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btfloat8sortsupport$$;

comment on function btfloat8sortsupport(internal) is 'sort support';

alter function btfloat8sortsupport(internal) owner to marina;

