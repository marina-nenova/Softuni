create function cashlarger(money, money) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cashlarger$$;

comment on function cashlarger(money, money) is 'larger of two';

alter function cashlarger(money, money) owner to marina;

