create function cash_lt(money, money) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_lt$$;

comment on function cash_lt(money, money) is 'implementation of < operator';

alter function cash_lt(money, money) owner to marina;

