create function convert_from(bytea, name) returns text
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_convert_from$$;

comment on function convert_from(bytea, name) is 'convert string with specified source encoding name';

alter function convert_from(bytea, name) owner to marina;

