create function btrim(text) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$btrim1$$;

comment on function btrim(text, text) is 'trim selected characters from both ends of string';

alter function btrim(text, text) owner to marina;

