create function brin_minmax_multi_distance_macaddr(internal, internal) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$brin_minmax_multi_distance_macaddr$$;

comment on function brin_minmax_multi_distance_macaddr(internal, internal) is 'BRIN multi minmax macaddr distance';

alter function brin_minmax_multi_distance_macaddr(internal, internal) owner to marina;

