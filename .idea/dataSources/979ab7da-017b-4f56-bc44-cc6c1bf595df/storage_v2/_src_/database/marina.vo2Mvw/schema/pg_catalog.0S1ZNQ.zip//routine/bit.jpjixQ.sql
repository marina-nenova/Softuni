create function bit(bigint, integer) returns bit
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bitfromint8$$;

comment on function bit(bit, int4, bool) is 'adjust bit() to typmod length';

alter function bit(bit, int4, bool) owner to marina;

