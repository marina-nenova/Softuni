create function character_length(text) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$textlen$$;

comment on function character_length(text) is 'character length';

alter function character_length(text) owner to marina;

