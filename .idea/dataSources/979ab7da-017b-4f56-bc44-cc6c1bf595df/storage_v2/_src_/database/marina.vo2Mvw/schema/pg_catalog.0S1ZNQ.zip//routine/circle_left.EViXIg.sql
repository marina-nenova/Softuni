create function circle_left(circle, circle) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$circle_left$$;

comment on function circle_left(circle, circle) is 'implementation of << operator';

alter function circle_left(circle, circle) owner to marina;

