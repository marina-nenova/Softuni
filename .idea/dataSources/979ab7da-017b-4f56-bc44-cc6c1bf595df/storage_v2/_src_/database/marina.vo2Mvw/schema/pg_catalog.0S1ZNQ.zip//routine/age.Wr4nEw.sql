create function age(xid) returns integer
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$xid_age$$;

comment on function age(timestamptz, timestamptz) is 'date difference preserving months and years';

alter function age(timestamptz, timestamptz) owner to marina;

