create function center(box) returns point
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_center$$;

comment on function center(box) is 'center of';

alter function center(box) owner to marina;

